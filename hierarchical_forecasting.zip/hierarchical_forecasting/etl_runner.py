# Databricks notebook source
import pyspark.sql.functions as F
import pyspark.sql.types as T

# COMMAND ----------

db_name = 'WMG'

# COMMAND ----------

sqlContext.sql(f"""CREATE DATABASE IF NOT EXISTS {db_name}""")

# COMMAND ----------

def query_sibling_data():
    query = """  
        SELECT
            artist.display_name AS artist_name,
            asset.sibling_id AS sibling_id,
            asset.family_id AS family_id,
            asset.asg_grouping_title AS sibling_title,
            ANY_VALUE(asset.afg_grouping_title) AS family_title,
            MIN(product.first_global_release_date) AS release_date
        FROM
            df_prod.dap.dim_product product
            INNER JOIN df_prod.dap.rel_product_asset_sibling asset ON asset.product_key = product.product_key
            INNER JOIN df_prod.dap.dim_artist artist ON asset.asg_primary_artist_id = artist.artist_key
        WHERE (product.first_global_release_date  > '2018-01-01'
               AND product.first_global_release_date  < current_date())
        GROUP BY
            asset.sibling_id,
            asset.family_id,
            asset.asg_grouping_title,
            artist.display_name
    """

    df = (
        spark
            .read
            .format("snowflake")
            .option("sfUrl", "https://wmg-datalab.snowflakecomputing.com")
            .option("sfUser", dbutils.secrets.get('arash.parnia','user'))
            .option("sfauthenticator", 'https://wmg.okta.com')
            .option("sfPassword", dbutils.secrets.get('arash.parnia', 'password'))
            .option("sfDatabase", "DF_PROD")
            .option("sfSchema", "DAP")
            .option("sfWarehouse", "ARASH_DATABRICKS")
            .option("query", query)
            .load()
            .withColumn('sibling_id',F.col('sibling_id').cast(T.IntegerType()))
    )

    return df

# COMMAND ----------

sibling_table_name = 'sibling'

query_sibling_data().write.format("delta").mode('overwrite').saveAsTable(db_name +"."+sibling_table_name)

# COMMAND ----------

def query_stream_data():   
    query =  """
        SELECT
            fact.product_key,
            fact.date_key,
            ANY_VALUE(asset.sibling_id) AS sibling_id,
            ANY_VALUE(asset.family_id) AS family_id,
            fact.country_code,
            fact.customer_key,
            DATEDIFF(week,
                     MIN(product.first_global_release_date),
                     fact.date_key) AS weeks_since_release,
            SUM(fact.stream_count) AS stream_count
        FROM
            df_prod.dap.dim_product product
            INNER JOIN df_prod.dap.fact_audio_streaming_agg_weekly fact ON product.product_key = fact.product_key
            INNER JOIN df_prod.dap.rel_product_asset_sibling asset ON asset.product_key = fact.product_key
        WHERE
              fact.date_key > '01/01/1950'
              AND fact.date_key < current_date()
              AND product.first_global_release_date > '01/01/1950'
              AND product.first_global_release_date  < current_date()
        GROUP BY
              fact.date_key,
              fact.product_key,
              fact.country_code,
              fact.customer_key
        HAVING weeks_since_release >= 0
        ORDER BY fact.date_key DESC
    """

    df = (
        spark
            .read
            .format("snowflake")
            .option("sfUrl", "https://wmg-datalab.snowflakecomputing.com")
            .option("sfUser", dbutils.secrets.get('arash.parnia','user'))
            .option("sfauthenticator", 'https://wmg.okta.com')
            .option("sfPassword", dbutils.secrets.get('arash.parnia','password'))
            .option("sfDatabase", "DF_PROD")
            .option("sfSchema", "DAP")
            .option("sfWarehouse",  "ARASH_DATABRICKS")
            .option("query", query)
            .load()
            .withColumn('product_key',F.col('product_key').cast(T.IntegerType()))
            .withColumn('customer_key',F.col('customer_key').cast(T.IntegerType()))
            .withColumn('sibling_id',F.col('sibling_id').cast(T.IntegerType()))
            .withColumn('stream_count',F.col('stream_count').cast(T.IntegerType()))
            .withColumn('weeks_since_release',F.col('weeks_since_release').cast(T.IntegerType()))
    )

    return df

# COMMAND ----------

def query_non_outlier_tracks():   
    query =  """
        WITH siblings AS (
            SELECT
                artist.display_name AS artist_name,
                asset.sibling_id AS sibling_id,
                asset.family_id AS family_id,
                asset.asg_grouping_title AS sibling_title,
                ANY_VALUE(asset.afg_grouping_title) AS family_title,
                MIN(product.first_global_release_date) AS release_date
            FROM    
                df_prod.dap.dim_product product
                INNER JOIN df_prod.dap.rel_product_asset_sibling asset ON asset.product_key = product.product_key
                INNER JOIN df_prod.dap.dim_artist artist ON asset.asg_primary_artist_id = artist.artist_key
            WHERE (product.first_global_release_date  > '2018-01-01'
                   AND product.first_global_release_date  < current_date())
            GROUP BY
                asset.sibling_id,
                asset.family_id,
                asset.asg_grouping_title,
                artist.display_name
        ),
        sib_streams AS (
            SELECT
                siblings.sibling_title, 
                siblings.sibling_id, 
                siblings.artist_name, 
                fact.customer_key, 
                fact.country_code,
                fact.date_key,
                siblings.release_date,
                SUM(fact.stream_count) AS stream_count
            FROM siblings
                INNER JOIN df_prod.dap.rel_product_asset_sibling asset on siblings.sibling_id = asset.sibling_id
                INNER JOIN df_prod.dap.fact_audio_streaming_agg_weekly fact on asset.product_key = fact.product_key
            GROUP BY 1, 2, 3, 4, 5, 6, 7
        ),
        sib_first_month_av AS (
            SELECT
                sib_streams.sibling_title, 
                sib_streams.sibling_id, 
                sib_streams.artist_name, 
                sib_streams.customer_key,
                sib_streams.country_code,
                sib_streams.release_date,
                AVG(sib_streams.stream_count) AS avg_first_month
            FROM sib_streams
            WHERE DATEDIFF(day,
                           sib_streams.release_date,
                           sib_streams.date_key) > 0
                  AND DATEDIFF(day,
                           sib_streams.release_date,
                           sib_streams.date_key) < 30 
            GROUP BY 1, 2, 3, 4, 5, 6
        ),
        lower_bounds AS (
            SELECT sib_first_month_av.artist_name,
                sib_first_month_av.customer_key,
                sib_first_month_av.country_code,
                PERCENTILE_CONT(0.1) within GROUP (ORDER BY sib_first_month_av.avg_first_month) AS lower_bound
            FROM sib_first_month_av
            GROUP BY sib_first_month_av.artist_name,
                     sib_first_month_av.customer_key,
                     sib_first_month_av.country_code
        )

        SELECT sib_first_month_av.sibling_id,
               sib_first_month_av.customer_key,
               sib_first_month_av.country_code,
               sib_first_month_av.avg_first_month
        FROM sib_first_month_av
        JOIN lower_bounds ON sib_first_month_av.customer_key = lower_bounds.customer_key 
            AND sib_first_month_av.country_code = lower_bounds.country_code
            AND sib_first_month_av.artist_name = lower_bounds.artist_name
        WHERE sib_first_month_av.avg_first_month > lower_bounds.lower_bound
    """

    df = (
        spark
            .read
            .format("snowflake")
            .option("sfUrl", "https://wmg-datalab.snowflakecomputing.com")
            .option("sfUser", dbutils.secrets.get('arash.parnia', 'user'))
            .option("sfauthenticator", 'https://wmg.okta.com')
            .option("sfPassword", dbutils.secrets.get('arash.parnia', 'password'))
            .option("sfDatabase", "DF_PROD")
            .option("sfSchema", "DAP")
            .option("sfWarehouse", "ARASH_DATABRICKS")
            .option("query", query)
            .load()
            .withColumn('CUSTOMER_KEY',F.col('CUSTOMER_KEY').cast(T.IntegerType()))
            .withColumn('sibling_id',F.col('sibling_id').cast(T.IntegerType()))
            .withColumn('AVG_FIRST_MONTH',F.col('AVG_FIRST_MONTH').cast(T.IntegerType()))
    )

    return df

# COMMAND ----------

stream_table_name = 'stream'

df_stream = query_sibling_data().join(query_non_outlier_tracks().select('sibling_id',
                                                                        'customer_key',
                                                                        'country_code',
                                                                        'avg_first_month'), ['sibling_id',
                                                                                             'customer_key',
                                                                                             'country_code'])

df_stream.write.format("delta").mode('overwrite').saveAsTable(f"{db_name}.{stream_table_name}")

# COMMAND ----------

sqlContext.sql(f"""optimize {db_name}.{sibling_table_name}""")

# COMMAND ----------

sqlContext.sql(f"""optimize {db_name}.{stream_table_name}""")
