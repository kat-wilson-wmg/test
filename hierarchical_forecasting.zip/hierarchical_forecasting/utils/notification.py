import logging
import os
from io import BytesIO
import json
import boto3
import base64
from botocore.exceptions import ClientError

class Notification:
  def send_email_pred(self,recipient,request,df , pred_fig, adspend_fig):

      if pred_fig:
        pred_buf = BytesIO()
        pred_fig.savefig(pred_buf, format="png")
        pred_image_data = base64.b64encode(pred_buf.getbuffer()).decode("ascii")
      else:
        pred_image_data = ''
     
      if adspend_fig is not None:
          adspend_buf = BytesIO()
          adspend_fig.savefig(adspend_buf, format="png")
          adspend_image_data = base64.b64encode(adspend_buf.getbuffer()).decode("ascii")
          ad_spend_html_str = f"""<h2>Ad Spend Visualization <h2/>
                                 <img src='data:image/png;base64,{adspend_image_data}'/>"""
      else:
          ad_spend_html_str = ''
      
      BODY_HTML = f"""<html>
                      <head></head>
                      <body>
                        <h1>WMG Data Science</h1>
                        <p>
                        Hello {request['CLIENT_NAME']},
                        <br> 
                        Your forecast request for {request['ARTIST_NAME']} has been completed.
                        <br> 
                        Please use your request id {request['REQUEST_ID']}  To view results here : <a href='Https://datascience.wmg.com/forecast'>https://datascience.wmg.com/forecast</a>
                        <br> 
                        request summery:
                        <ul>
                          <li>REQUEST_ID: {request['REQUEST_ID']}</li>
                          <li>ARTIST_NAME: {request['ARTIST_NAME']}</li>
                          <li>TRACK_NAME: {request['TRACK_NAME']}</li>
                          <li>COUNTRY_CODE: {request['COUNTRY_CODE']}</li>
                          <li>DSP: {request['DSP']}</li>
                          <li>ADSPEND: {request['ADSPEND']}</li>
                        </ul>    
                                                
                        </p>
                        <h2>Prediction Visualization <h2/>
                        <img src='data:image/png;base64,{pred_image_data}'/>
                        {ad_spend_html_str}
                        <h2>Comps Table <h2/>
                        {df.to_html()}
                      </body>
                      </html>
                  """
      return self.send_email(recipient,BODY_HTML)

  def send_email_fail(self,recipient,error_message=None):

      BODY_HTML = f"""<html>
                      <head></head>
                      <body>
                        <h1>WMG Data Science</h1>
                        <h2>Your forecast request has failed to completed. </h2>
                        <p>{error_message}</p>
                        
                      </body>
                      </html>
                  """
      return self.send_email(recipient,BODY_HTML)


  def send_email(self,recipient,BODY_HTML):

      client = boto3.client('pinpoint')

      from botocore.exceptions import ClientError
      BODY_TEXT = """WMG Data Science
                   Your forecast request has been processed.
                   https://datascience.wmg.com/forecast
                """
      try:
          response = client.send_messages(
              ApplicationId='07bb249a64814feb93a38ba2b24c8932',
              MessageRequest={
                  'Addresses': {
                      recipient: {
                          'ChannelType': 'EMAIL'
                      }
                  },
                  'MessageConfiguration': {
                      'EmailMessage': {
                          'FromAddress': "hierarchical-forecasting<hierarchical-forecasting@wmg-datascience.awsapps.com>",
                          'SimpleEmail': {
                              'Subject': {
                                  'Charset': "UTF-8",
                                  'Data': "Forecast Notification"
                              },
                              'HtmlPart': {
                                  'Charset': "UTF-8",
                                  'Data': BODY_HTML
                              },
                              'TextPart': {
                                  'Charset': "UTF-8",
                                  'Data': BODY_TEXT
                              }
                          }
                      }
                  }
              }
          )
      except ClientError as e:
          return (e.response['Error']['Message'])
      else:
          return ("Message sent! Message ID: "
                  + response['MessageResponse']['Result'][recipient]['MessageId'])


  def update_status(self, request_id, status):

      try:

          df = spark.createDataFrame(data=[(request_id, status)]
                                     , schema=["request_id", "status"]
                                     ).withColumn("status_timestamp", F.current_timestamp())

          df.write \
              .format("snowflake") \
              .mode("append") \
              .option("sfUser", self.secret['username']) \
              .option("sfPassword", self.secret['password']) \
              .option("sfUrl", "https://wmg-datalab.snowflakecomputing.com") \
              .option("sfDatabase", "DATA_SCIENCE_SANDBOX") \
              .option("sfSchema", "ARASH_P") \
              .option("sfWarehouse", "SYSTEMACCOUNT") \
              .option("dbtable", f"REQUEST_STATUS") \
              .save()
      except:
          print('error sending status update')
          raise

      return status
