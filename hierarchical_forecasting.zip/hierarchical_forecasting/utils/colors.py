import seaborn as sns

def sns_paired_pallete_colors(dark=True):
    """Colors for the prediction time series plot.

    Returns
        dict: Contains colors for prediction and plots.
    """
    colors = list(sns.color_palette("Paired", 20))
    remainder = 0 if dark else 1
    bar_colors = [color for i, color in enumerate(colors) if i % 2 == remainder]
    return bar_colors
