class dsps:

    @staticmethod
    def _dsp_dict():
        dict_ = {
            "Spotify": 1,
            "Deezer": 3,
            "Google": 4,
            "Amazon Prime": 5,
            "Amazon Unlimited": 119735,
            "YouTube": 140003,
            "KT": 143531,
            "Loen": 143533,
            "Line Music": 143535,
            "RecoChoku": 143536,
            "Pandora": 143537,
            "iHeartRadio": 143538,
            "Mnet": 144041,
            "Bugs": 144121,
            "SoundCloud": 145581,
            "AWA": 154334,
            "Melon": 156423,
            "Amazon Ad Supported": 155643,
            "Simfy": 154481,
            "Spice": 154482,
            "Joox": 154484,
            "Boomplay": 154485,
            "Yandex": 285183,
            "TikTok - Views": 285184,
            "Douyin - Views": 285185,
            "Anghami": 285303,
            "QQ": 285673,
            "KuWo": 285674,
            "KuGou": 285675,
            "UMA": 285804,
            "NetEase": 285803,
            "Apple Music": 2,
            "TDC - YouSee": 287723,
            "TDC - Telmore Musik": 287724,
            "Peloton": 288053,
            "SberZvuk": 288123,
        }
        customer_id_dict = dict(zip(dict_.values(), dict_.keys()))
        return customer_id_dict
