class weekdays:

   @staticmethod
   def weekdays():
       days = [
           "Friday",
           "Saturday",
           "Sunday",
           "Monday",
           "Tuesday",
           "Wednesday",
           "Thursday",
       ]
       return days