import datetime as dt
import logging
import math

from itertools import product
from functools import reduce

import numpy as np
import pandas as pd

from sklearn import preprocessing

from hierarchical_forecasting.pre_processing.comps_filter import similar_streams_filter
from hierarchical_forecasting.modeling.dimensions import Dimensions
from hierarchical_forecasting.pre_processing import ad_spend_data_pull
from hierarchical_forecasting.utils.weekdays import weekdays
from hierarchical_forecasting.utils.dsps import dsps
from hierarchical_forecasting.utils.ordered_encoder import MyLabelEncoder


class DataProcessing:
    def __init__(self, request_artist, request_track, request_sibling_id, request_comps_count):
        """Initialize class instance.

        Args:
            artist_name (str):
            prediction_track_name (str):
            model_data_df (pd.DataFrame):
        """
        self.request_artist = request_artist
        self.request_track = request_track
        self.request_sibling_id = str(request_sibling_id)
        self.request_comps_count = request_comps_count
        self.comps = None
        self.ad_spend_flag = False
        self.n_similar_comps=10

    def _fix_siblings_with_multiple_artists(self, data_df):
        """Fixes the rare issue when a sibling has multiple artist names

        Args:
            data_df (pd.DataFrame)

        Returns:
            Modified DataFrame.
        """

        sibling_artist = data_df[
            ["sibling_id", "PRODUCT_ARTIST_NAME"]
        ].drop_duplicates()
        sibling_artist_dict = sibling_artist.set_index("sibling_id").to_dict()[
            "PRODUCT_ARTIST_NAME"
        ]
        sibling_artist_dict[self.request_sibling_id] = self.request_artist
        data_df["PRODUCT_ARTIST_NAME"] = data_df["sibling_id"].apply(
            lambda x: sibling_artist_dict[x]
        )

        return data_df

    def _to_datetime(self, data_df, cols):
        """Turns columns to datetime type.

        Args:
            data_df (pd.DataFrame):
            cols (list): list of column names

        Returns:
            Modified DataFrame.
        """
        for col in cols:
            data_df[col] = pd.to_datetime(data_df[col])

        return data_df

    def _resolve_release_date(self, data_df):
        """Determines release date to be latest between the
        date of first observaition or the database release date
        per dsp and sibling_id
                Args:
                    data_df (pd.DataFrame):

                Returns:
                    Modified DataFrame.
        """
        agg_dict = {"DATE_KEY": np.nanmin, "PRODUCT_RELEASE_DATE": "first"}
        agg_cols = ["sibling_id", "CUSTOMER_KEY"]
        release_date_df = data_df.groupby(agg_cols).agg(agg_dict).reset_index()
        date_col = release_date_df["DATE_KEY"]
        rel_date_col = release_date_df["PRODUCT_RELEASE_DATE"]
        rel_date_resolved = pd.concat([date_col, rel_date_col]).max(
            level=0
        )
        release_date_df["RELEASE_DATE"] = rel_date_resolved
        release_date_df = release_date_df[
            ["sibling_id", "CUSTOMER_KEY", "RELEASE_DATE"]
        ]
        data_df = data_df.merge(release_date_df, on=agg_cols)
        return data_df

    def _set_release_date(self, data_df):

        """Stores the release date of request track per dsp
        as an attribute of the data_processing object.

        Args:
            data_df (pd.DataFrame):

        """
        main_track_df = data_df[data_df['sibling_id'] == self.request_sibling_id]
        release_dates = main_track_df.drop_duplicates('DSP').set_index('DSP')
        dsps = data_df.drop_duplicates('DSP')['DSP'].values
        release_dates_dict = release_dates['RELEASE_DATE'].to_dict()
        if len(release_dates_dict):
            for k,v in release_dates_dict.items():
                release_dates_dict[k] = v.date()
        else:
            for k in dsps:
                release_dates_dict[k] = dt.datetime.today().date()
        self.request_release_dates = release_dates_dict

    def _filter_comps(self, data_df):
        """Filters siblings to those with comparable number of daily streams.
        Args:
            data_df (pd.DataFrame):

        Returns:
            filtered_data_df (pd.DataFrame):
        """
        if self.request_sibling_id == "None":
            output_data_df = data_df.copy()
        else:
            output_data_df = similar_streams_filter(
                data_df,
                self.request_sibling_id,
                self.n_similar_comps
        )
        self.comps = list(output_data_df['sibling_id'].unique())
        return output_data_df

    def _set_last_obs_date(self, data_df):
        """Stores the date of last observation
            as an attribute of the data_processing object.

            Args:
                data_df (pd.DataFrame):

            """
        self.last_observation_date = data_df['DATE_KEY'].max().date()

    def _agg_dataframe(self, data_df, agg_dict, agg_cols, drop=False):
        """Aggregates columns based on aggregation rules.

        Args:
            data_df (pd.DataFrame):
            agg_dict (dict): agg rule for columns in aggregation
            agg_cols (list): list of column to aggregate on

        Returns:
            Aggregated DataFrame.
        """
        data_df = data_df.groupby(agg_cols).agg(agg_dict).reset_index(drop=drop)

        return data_df

    def _add_age(self, data_df):
        """Appends columns with age of track, weeks since release, and day of weeks.

        Args:
            data_df (pd.DataFrame): data

        Returns:
            DataFrame with age column.
        """
        data_df["PRODUCT_AGE_DAYS"] = (
            data_df["DATE_KEY"] - data_df["RELEASE_DATE"]
        ).dt.days
        data_df["w"] = data_df["PRODUCT_AGE_DAYS"].values // 7
        data_df["DAY_OF_WEEK"] = data_df["DATE_KEY"].dt.day_name()
        data_df = data_df[data_df["w"] >= 0]

        return data_df

    def _add_dsp(self, data_df):
        """Appends a column with the DSP name.

        Args:
            data_df (pd.DataFrame)

        Returns:
            DataFrame with DSP name
        """
        dsp_dict = dsps._dsp_dict()
        data_df["DSP"] = data_df["CUSTOMER_KEY"].apply(lambda x: dsp_dict[x])
        data_df["DSP"] = data_df["DSP"].astype(str)
        data_df.drop('CUSTOMER_KEY', axis=1, inplace=True)
        return data_df

    def _clean_ad_data(self, ad_data):
        """Cleans up and aggregates the ad dataframe across ad-campaigns.

        Args:
            ad_data (pd.DataFrame):

        Returns:
            Cleaned up DataFrame.
        """
        ad_data = self._to_datetime(ad_data, cols=["DAY"])
        ad_data["sibling_id"] = ad_data["SIBLING_ID"].astype(str)
        ad_data = ad_data[["DAY", "CHANNEL", "sibling_id", "SPEND_USD"]]
        ad_data.columns = ["DATE_KEY", "CHANNEL", "sibling_id", "SPEND_USD"]
        agg_cols = ["DATE_KEY", "CHANNEL", "sibling_id"]
        agg_dict = {"SPEND_USD": sum}
        ad_data = self._agg_dataframe(ad_data, agg_dict, agg_cols)

        return ad_data

    def _flag_ad_spend(self, ad_data):
        self.ad_spend_flag = ad_spend_data_pull.has_ad_spend_data(ad_data)

    def _merge_ad_spend(self, stream_data, ad_data):
        """Merges streaming data and ad spend data. if no ad spend data, creates mock channel.

        Args:
            stream_data (pd.DataFrame): streaming data
            ad_data (pd.DataFrame): ad spend data

        Returns:
            Streaming merged with ad spend DataFrame.
        """
        if self.ad_spend_flag:
            ad_data = self._clean_ad_data(ad_data)
            ad_data_pivoted = ad_data.pivot(
                index=["DATE_KEY", "sibling_id"],
                columns=["CHANNEL"],
                values=["SPEND_USD"],
            ).reset_index()
            ad_data_pivoted.columns = ["DATE_KEY", "sibling_id"] + [
                "_".join(col) for col in ad_data_pivoted.columns if col[1] != ""
            ]
            df_merged = stream_data.merge(
                ad_data_pivoted, how="left", on=["DATE_KEY", "sibling_id"]
            )
            df_merged = df_merged.fillna(0)
        else:
            df_merged = stream_data.copy()
            df_merged["SPEND_mock_chn"] = 0

        return df_merged

    def _merge_playlist(self, data_df, playlist_data):
        """Merges streaming/ad data and playlist data.

        Args:
            data_df (pd.DataFrame): streaming/ad data
            playlist_data (pd.DataFrame): playlist data

        Returns:
            Streaming/ad merged with playlist DataFrame.
        """

        if playlist_data is not None:
            playlist_data['sibling_id'] = playlist_data['sibling_id'].astype(str)
            playlist_data['DATE_KEY'] = pd.to_datetime(playlist_data['DATE_KEY'])
            df_merged_with_playlist = data_df.merge(
                playlist_data, on=["sibling_id", "DATE_KEY", "DSP"], how="left"
            )
        else:
            df_merged_with_playlist = data_df
            df_merged_with_playlist['pl_score'] = 0.

        return df_merged_with_playlist

    def _merge_aural(self, data_df, aural_data):
        """Merges streaming/ad/playlist data and aural features data.
        Args:
            data_df (pd.DataFrame): streaming/ad/playlist data
            aural_data (pd.DataFrame): aural data

        Returns:
            Streaming/ad/playlist merged with aural features DataFrame.
        """
        if aural_data is not None:
            aural_data['sibling_id'] = aural_data['sibling_id'].astype(str)
            df_merged_with_aural = data_df.merge(
                aural_data, on=["sibling_id"], how="left"
            )
        else:
            df_merged_with_aural = data_df

        return df_merged_with_aural

    def _clean_data(
        self,
        stream_data,
        ad_data=None,
        playlist_data=None,
        aural_data=None,
    ):
        """Combines different sources of data.

        Args:
            stream_data (pd.DataFrame): streaming data
            ad_data (pd.DataFrame): ad spend data
            playlist_data (pd.DataFrame): playlist features data
            aural_data (pd.DataFrame): aural features data

        Returns:
            Combined training DataFrame.
        """
        column_names = [
            "sibling_id",
            "DATE_KEY",
            "CUSTOMER_KEY",
            "PRODUCT_RELEASE_DATE",
            "PRODUCT_ARTIST_NAME",
            "STREAM_COUNT",
        ]
        data_df = stream_data[column_names].copy()

        data_df["sibling_id"] = data_df["sibling_id"].astype(str)
        date_type_cols = ["DATE_KEY", "PRODUCT_RELEASE_DATE"]
        data_df = self._to_datetime(data_df, cols=date_type_cols)

        data_df = self._fix_siblings_with_multiple_artists(data_df)
        data_df = self._resolve_release_date(data_df)
        data_df = self._add_dsp(data_df)

        self._set_release_date(data_df) # todo: shouldn be in __init__
        self._set_last_obs_date(data_df) # todo: shouldn be in __init__

        data_df = self._filter_comps(data_df)

        agg_dict = {
            "STREAM_COUNT": sum,
            "PRODUCT_ARTIST_NAME": "first",
            "RELEASE_DATE": min,
        }
        agg_cols = ["DATE_KEY", "DSP", "sibling_id"]
        data_df = self._agg_dataframe(data_df, agg_dict, agg_cols)

        data_df = self._add_age(data_df)

        self._flag_ad_spend(ad_data)  # todo: remove run init with ad_data
        stream_ad_df = self._merge_ad_spend(data_df, ad_data)

        stream_ad_pl_df = self._merge_playlist(stream_ad_df, playlist_data)

        stream_ad_pl_au_df = self._merge_aural(stream_ad_pl_df, aural_data)

        sort_cols = ["PRODUCT_ARTIST_NAME", "sibling_id", "w", "DAY_OF_WEEK", "DSP"]
        stream_ad_pl_au_df = stream_ad_pl_au_df.sort_values(sort_cols, ascending=True)

        return stream_ad_pl_au_df.reset_index(drop=True)

    def _pivot_data(self, data_df, index_cols, pivot_col, value_col):
        """Pivots table and reindex.

        Args:
            data_df (pd.DataFrame): training data to pivot
            index_cols (list): index_cols for pivot
            pivot_col (str): col name to pivot on
            value_col (str): col name to fill values

        Returns:
            Pivoted DataFrame.
        """
        data_pivoted_df = data_df.pivot(
            index=index_cols, columns=pivot_col, values=value_col
        )
        cols = data_pivoted_df.columns
        col_dsps  = cols.get_level_values(1)
        col_labels = cols.get_level_values(0)
        new_cols = [f'{lb}_{dsp}' for lb,dsp in zip(col_labels,col_dsps)]
        data_pivoted_df.columns = new_cols
        data_pivoted_df.reset_index(inplace=True)
        return data_pivoted_df

    def _get_artist_name_for_sibling_id(self, data_df, sibling_id):
        """Finds artist name of a sibling id from streaming data.

        Args:
            data_df (pd.DataFrame): streaming data
            sibling_id (str):

        Returns:
            String of artist name.
        """
        data_filterd = data_df[data_df["sibling_id"] == sibling_id]
        artist_name = data_filterd["PRODUCT_ARTIST_NAME"].values[0]

        return artist_name

    def _fill_missing_data(self, data_df, tracks, weeks, days, dsps, channels):
        """Adds row to streaming data so that every track has value (nan) for every day and week.

        Args:
            data_df (pd.DataFrame): training data
            tracks (list): list of sibling ids
            weeks (list): list of week numbers
            days (list): list of days of the week
            dsps (list): list of dsps
            channels (list): list of ad channels

        Returns:
            DataFrame filled with np.nan for missing values.
        """
        for sibling_id in tracks:
            track_df = pd.DataFrame(
                list(product(weeks, days, dsps)), columns=["w", "DAY_OF_WEEK", "DSP"]
            )
            track_df["sibling_id"] = sibling_id
            artist_name = self._get_artist_name_for_sibling_id(data_df, sibling_id)
            track_df["PRODUCT_ARTIST_NAME"] = artist_name
            for channel in channels:
                track_df[channel] = 0
            data_df = pd.concat([data_df, track_df], axis=0, ignore_index=True)

        return data_df

    def _add_new_rel(self, artist, weeks, days, dsps, channels):
        """If the prediction is for a new release makes (np.nan) streaming data
        and 0 ad spend for the new release.

        Args:
            artist (str): requested artist name
            weeks (list): list of week numbers
            days (list): list of days of the week
            dsps (list): list of dsps
            channels (list): list of ad channels

        Returns:
            New release DataFrame.
        """
        new_release = pd.DataFrame(
            list(product(weeks, days, dsps)), columns=["w", "DAY_OF_WEEK", "DSP"]
        )
        new_release["sibling_id"] = "New Release"
        new_release["PRODUCT_ARTIST_NAME"] = artist
        for channel in channels:
            new_release[channel] = 0

        return new_release

    def _append_new_release(self, data_df, weeks, days, dsps, channels):
        """Appends the new release to the training data.

        Args:
            data_df (pd.DataFrame): training data
            weeks (list): list of week numbers
            days (list): list of days of the week
            dsps (list): list of dsps
            channels (list): list of ad channels

        Returns:
            DataFrame with the new release appended.
        """
        new_release = self._add_new_rel(
            self.request_artist, weeks, days, dsps, channels
        )
        data_df = pd.concat([data_df, new_release], axis=0, ignore_index=True)
        data_df["request_artist"] = (
            data_df["PRODUCT_ARTIST_NAME"] == self.request_artist
        )
        data_df["request_sibling_id"] = data_df["sibling_id"] == "New Release"

        return data_df

    def _prepare_prediction_level(self, data_df, artists, weeks, days, dsps, channels):
        """Determines the prediction level and re-orders the prediction track last

        Args:
            data_df (pd.DataFrame): training data
            tracks (list): list of tracks ids
            artists (list): list of artists names
            weeks (list): list of week numbers
            days (list): list of days of the week
            dsps (list): list of dsps
            channels (list): list of ad channels

        Returns:

        """
        if self.request_artist not in artists:
            self.level = "TOP"
            data_df = self._append_new_release(
                data_df, weeks, days, dsps, channels
            )

        elif self.request_sibling_id == "None":
            self.level = "ARTIST"

            data_df = self._append_new_release(
                data_df, weeks, days, dsps, channels
            )

        else:
            self.level = "TRACK"
            data_df["request_artist"] = (
                data_df["PRODUCT_ARTIST_NAME"] == self.request_artist
            )
            data_df["request_sibling_id"] = (
                data_df["sibling_id"] == self.request_sibling_id
            )

        sort_cols = [
            "request_sibling_id",
            "request_artist",
            "PRODUCT_ARTIST_NAME",
            "sibling_id",
            "w",
            "DAY_OF_WEEK",
            "DSP",
        ]
        data_df = data_df.sort_values(sort_cols)
        return data_df

    def _encode_tracks(self, data_df):
        """trains a label encoder on tracks ids
        Args:
            data_df (pd.DataFrame): training data
        """
        track_le = MyLabelEncoder()
        track_le.fit(data_df["sibling_id"])
        data_df["track_id"] = track_le.transform(data_df["sibling_id"])
        return data_df, track_le

    def _encode_artists(self, data_df):
        """trains a label encoder on artists names
        Args:
            data_df (pd.DataFrame): training data
        """
        artist_le = MyLabelEncoder()
        artist_col = data_df["PRODUCT_ARTIST_NAME"]
        artist_le.fit(artist_col)
        data_df["artist_id"] = artist_le.transform(artist_col)
        return data_df, artist_le

    def _encode_features(self, feature_cols):
        """trains a label encoder on features names
        Args:
            data_df (pd.DataFrame): training data
        """
        feature_le = MyLabelEncoder()
        feature_le.fit(feature_cols)
        return feature_le

    def _encode_days(self, data_df, days):
        """trains a label encoder on days names
        Args:
            data_df (pd.DataFrame): training data
        """
        days_le = MyLabelEncoder()
        days_col = data_df["DAY_OF_WEEK"]
        days_le.fit(days)
        data_df["day_id"] = days_le.transform(days_col)
        return data_df, days_le

    def _make_tensor(self, data_df):
        """puts training data into a tensor of dim=(tracks,weeks,days,features+dsps)
        Args:
            data_df (pd.DataFrame): training data
        """
        Xs = []
        for day in range(7):
            day_info = data_df[data_df["day_id"] == day]
            iix = pd.MultiIndex.from_product(
                [np.unique(day_info["w"]), np.unique(day_info["feature"])]
            )
            df_pivot = day_info.pivot_table(
                "value", "track_id", ["w", "feature"], aggfunc="first"
            ).reindex(iix, axis=1)
            Z = np.array(
                df_pivot.groupby(level=0, axis=1)
                .agg(lambda x: [*x.values])
                .to_numpy()
                .tolist()
            )
            Xs.append(Z)
        X = np.stack(Xs, axis=-2)
        return X

    def data_preparation(self, data_df, ad_data=None, playlist_data=None, aural_data=None):

        train_data_df = self._clean_data(
            data_df, ad_data=ad_data, playlist_data=playlist_data, aural_data=aural_data
        )
        data_columns = set(train_data_df.columns)

        tracks = set(train_data_df["sibling_id"].unique())
        artists = set(train_data_df["PRODUCT_ARTIST_NAME"].unique())
        max_week = train_data_df["w"].max()
        weeks = np.arange(max_week + 52)
        days = weekdays.weekdays()

        n_weeks = len(weeks)
        n_days = len(days)

        index_cols = data_columns.difference(["DSP", "STREAM_COUNT","pl_score"])
        pivot_col = "DSP"
        value_col = ["STREAM_COUNT", "pl_score"]
        data_pivoted_df = self._pivot_data(
            train_data_df, index_cols, pivot_col, value_col
        )
        data_columns_pivoted = data_pivoted_df.columns
        dsps =[col for col in data_columns_pivoted if col.startswith("STREAM_COUNT_")]
        channels = [col for col in data_columns_pivoted if col.startswith("SPEND")]
        aural_feats = [col for col in data_columns_pivoted if col.startswith("aural_score")]
        pl_feats = [col for col in data_columns_pivoted if col.startswith("pl_score")]

        n_dsps = len(dsps)
        n_channels = len(channels)
        n_aural_feats = len(aural_feats)
        n_pl_feats = len(pl_feats)
        n_features = n_channels + n_aural_feats + n_pl_feats

        data_filled_df = self._fill_missing_data(
            data_pivoted_df, tracks, weeks, days, dsps, channels
        )
        train_data_df = self._prepare_prediction_level(
            data_filled_df, artists, weeks, days, dsps, channels
        )

        tracks_updated = set(train_data_df["sibling_id"].unique())
        artists_updated = set(train_data_df["PRODUCT_ARTIST_NAME"].unique())

        n_tracks = len(tracks_updated)
        n_artists = len(artists_updated)

        train_data_df, track_le = self._encode_tracks(train_data_df)
        train_data_df, artist_le = self._encode_artists(train_data_df)
        train_data_df, days_le = self._encode_days(train_data_df, days)

        feature_cols = dsps + channels + pl_feats + aural_feats
        features_le = self._encode_features(feature_cols)

        tags = {}
        tags["track_to_artist_dict"] = train_data_df.drop_duplicates("track_id")[
            "artist_id"
        ].values

        index_cols = ["w", "track_id", "day_id"]
        index_cols_plus_artists = index_cols + ["artist_id"]
        train_data_df = train_data_df[
            index_cols_plus_artists + feature_cols
        ].reset_index(drop=True)

        train_melted_df = train_data_df.melt(
            id_vars=index_cols,
            value_vars=feature_cols,
            value_name="value",
            var_name=["feature"],
        )

        train_melted_df["feature"] = features_le.transform(train_melted_df["feature"])

        X = self._make_tensor(train_melted_df)

        obs_features = np.array(
            [feature.startswith("STREAM_COUNT_") for feature in features_le.classes_]
        )
        y = X[..., obs_features]
        X = X[..., ~obs_features]
        denom = np.max(np.nan_to_num(y)) / 10000.0
        y = y / denom

        dims_dict = {
            "n_tracks": n_tracks,
            "n_artists": n_artists,
            "n_weeks": n_weeks,
            "n_days": n_days,
            "n_features": n_features,
            "n_channels": n_channels,
            "n_pl_feats": n_pl_feats,
            "n_aural_feats": n_aural_feats,
            "n_dsps": n_dsps,
        }
        dimensions = Dimensions(dims_dict)
        tags['dimensions'] = dimensions

        self.dims = dimensions
        self.denom = denom
        self.artist_le = artist_le
        self.track_le = track_le
        self.days_le = days_le
        self.features_le = features_le

        return X, y, tags

    def _update_artist_level(self, tags, artist_set, test_artists):
        tags["artist_level"] = np.where(np.isin(artist_set, test_artists), 0.0, 1.0)
        if self.level != "TRACK":
            tags["artist_level"][-1] = 0
        return tags

    def _test_train_artists(self, is_test, tags, artist_group_ids, test_size):
        """Leaves all the tracks of test size * total number of artists for testing.
        Args:
            is_test (np.array): boolean indicator of test data points
            tags (dict): dictionary of hierarchical info
            artist_group_ids (np.array): artist id of each track in training
            test size (float)
        Returns:
            List of tracks that are not in test & updated is_test with new test points and tags.
        """
        artist_set = np.unique(artist_group_ids)
        potential_artists = artist_set[:-1]
        test_sample = int(test_size * potential_artists.shape[0])
        test_artists = np.random.choice(
            potential_artists, size=test_sample, replace=False
        )
        test_artists_tracks = np.where(np.isin(artist_group_ids, test_artists))[0]
        is_test[test_artists_tracks, ...] = 1
        potential_artists = np.setdiff1d(potential_artists, test_artists)
        remaining_tracks = np.where(np.isin(artist_group_ids, potential_artists))[0]
        tags = self._update_artist_level(tags, artist_set, test_artists)
        return tags, remaining_tracks, is_test

    def _back_test_split(self, is_test, y, remaining_tracks, test_size):
        """Leaves test_size fraction of exititing weeks in the time series for testing
        Args:
            is_test (np.array): boolean indicator of test data points
            remaining_tracks (np.array): list of track to choose from
            test size (float)
        Returns:
            List (updated) of tracks that are not in test & updated is_test with new test points.
        """
        test_sample = int(test_size * remaining_tracks.shape[0])
        back_test_tracks = np.random.choice(
            remaining_tracks, size=test_sample, replace=False
        )
        for track in back_test_tracks:
            max_week = np.argmax(np.isnan(y[track, :, -1]))
            look_ahead = test_size * max_week
            test_weeks = (max_week - look_ahead).astype(int)
            is_test[track, test_weeks:, :] = 1
        remaining_tracks = np.setdiff1d(remaining_tracks, back_test_tracks)
        return remaining_tracks, is_test

    def _update_track_level(self, tags, track_set, test_tracks):

        artist_level = tags["artist_level"]
        artist_group_ids = tags["track_to_artist_dict"]
        test_artist = np.where(artist_level == 0)[0]
        artist_level_tracks = np.where(np.isin(artist_group_ids, test_artist), 0.0, 1.0)
        test_track_level = np.where(np.isin(track_set, test_tracks), 0.0, 1.0)
        tags["track_level"] = np.logical_and(
            artist_level_tracks, test_track_level
        ).astype(int)
        if self.level != "TRACK":
            tags["track_level"][-1] = 0

        return tags

    def _test_train_tracks(self, is_test, tags, remaining_tracks, test_size):
        """Leaves test_size fraction of remaining tracks to be test as new releases
        Args:
            is_test (np.array): boolean indicator of test data points
            tags (dict): dictionary of hierarchical info
            remaining_tracks (np.array): list of track to choose from
            test size (float)
        Returns:
            Updated is_test with new test points and updates tags.
        """
        test_sample = int(test_size * len(remaining_tracks))
        test_tracks = np.random.choice(
            remaining_tracks, size=test_sample, replace=False
        )
        is_test[test_tracks, ...] = 1
        n_tracks = is_test.shape[0]
        track_set = np.arange(0, n_tracks)
        tags = self._update_track_level(tags, track_set, test_tracks)

        return tags, is_test

    def _get_X_train_y_train(self, X, y, is_test, is_train):
        """Creates X_train, X_test like X and y_train, y_test like y, where train
        tensors only have the training values (o.w. np.nan) and test tensors only
        have test values.
        Args:
            is_test (np.array): boolean indicator of test data points
            is_train (np.array): boolean indicator of training data points
            X (np.array): feature data
            y (np.aray): target data
        Returns:
            Arrays of training data and test data
        """
        is_train = np.where(is_train, 1, np.nan)
        y_train = y * is_train
        X_train = X * is_train
        is_test = np.where(is_test, 1, np.nan)
        y_test = y * is_test
        X_test = X * is_test
        return X_train, X_test, y_train, y_test

    def _back_test_main_track(self, X, y, forecast_horizon, back_test_window, is_test, is_train):
        is_test[-1, back_test_window: back_test_window + forecast_horizon, :] = 1
        is_train[-1:, :back_test_window, :] = 1
        return is_test, is_train

    def test_train_split(self, X, y, tags, forecast_horizon, back_test_window=5, test_size=0.1):

        artist_group_ids = tags["track_to_artist_dict"]
        is_test = np.zeros_like(y[..., -1:])
        is_train = np.zeros_like(y[..., -1:])

        is_test, is_train = self._back_test_main_track(X, y, forecast_horizon, back_test_window, is_test, is_train)
        X_train, X_test, y_train, y_test = self._get_X_train_y_train(X, y, is_test, is_train)
        return X_train, X_test, y_train, y_test, tags

    def _samples_to_df(self, le_dict, y_pred_samples, q):
        n_samples, n_tracks, n_weeks, n_days, n_dsps = y_pred_samples.shape
        y_pred_quantile = np.maximum(np.quantile(y_pred_samples, q=q, axis=0), 0)
        y_pred_quantile = y_pred_quantile.reshape(
            n_tracks, n_weeks * n_days * n_dsps, order="C"
        )
        df = pd.DataFrame(y_pred_quantile.T)
        df["w"] = df.index // (n_days * n_dsps)
        df["dsp"] = df.index % (n_dsps)
        df["d"] = (df.index % (n_days * n_dsps)) // (n_dsps)
        df["DSP"] = le_dict["features"].inverse_transform(df["dsp"])
        df["DAY_OF_WEEK"] = le_dict["days"].inverse_transform(df["d"])
        df.drop("d", axis=1, inplace=True)
        df_melted = df.melt(
            id_vars=["w", "DAY_OF_WEEK", "DSP"],
            value_vars=np.arange(n_tracks),
            value_name="{}-ptile-streams".format(int(q * 100)),
            var_name=["track_id"],
        )
        return df_melted

    def post_proccessing(self, y_pred_samples, tags, le_dict):
        n_samples, n_tracks, n_weeks, n_days, _ = y_pred_samples.shape
        ptiles = [0.05, 0.25, 0.5, 0.75, 0.9]
        artist_group_ids = np.array(tags["track_to_artist_dict"])
        track_le = le_dict["track"]
        artist_le = le_dict["artist"]
        y_ptiles = [self._samples_to_df(le_dict, y_pred_samples, q) for q in ptiles]
        df_merged = reduce(
            lambda left, right: pd.merge(
                left, right, on=["track_id", "w", "DAY_OF_WEEK", "DSP"], how="outer"
            ),
            y_ptiles,
        )
        df_merged["track_id"] = df_merged["track_id"].astype(int)
        df_merged["sibling_id"] = track_le.inverse_transform(df_merged["track_id"])
        df_merged["sibling_id"] = df_merged["sibling_id"].apply(
            lambda x: x.split(" ")[-1]
        )
        df_merged["sibling_id"] = pd.to_numeric(
            df_merged["sibling_id"], errors="coerce"
        )
        df_merged["sibling_id"] = df_merged["sibling_id"].fillna("New Release")
        df_merged["ARTIST_ID"] = df_merged["track_id"].apply(
            lambda x: artist_group_ids[x]
        )
        df_merged["PRODUCT_ARTIST_NAME"] = artist_le.inverse_transform(
            df_merged["ARTIST_ID"]
        )
        df_merged["PRODUCT_ARTIST_NAME"] = df_merged["PRODUCT_ARTIST_NAME"].apply(
            lambda x: "New Artist" if x == "TOP" else x
        )

        df_output = df_merged[
            ["PRODUCT_ARTIST_NAME", "sibling_id", "w", "DAY_OF_WEEK", "DSP"]
            + ["{}-ptile-streams".format(int(q * 100)) for q in ptiles]
        ]
        df_output = df_output.sort_values(
            ["PRODUCT_ARTIST_NAME", "sibling_id", "w", "DAY_OF_WEEK", "DSP"]
        )
        return df_output.reset_index(drop=True)

    def opt_allocation_table(self, opt_alloc_matrix, le_dict):
        alloc_df = pd.DataFrame()
        n_channels = opt_alloc_matrix.shape[-1]
        for ch in range(n_channels):
            df = pd.DataFrame(opt_alloc_matrix[:, :, ch])
            chn_name = le_dict["features"].inverse_transform([ch])[0]
            df["channel"] = chn_name.split("_")[-1]
            alloc_df = pd.concat([alloc_df, df], axis=0)
        cols = le_dict["days"].inverse_transform(
            alloc_df.columns[:-1].tolist()
        ).tolist() + ["channel"]
        alloc_df.columns = cols
        alloc_df["week"] = alloc_df.index + 1
        alloc_df.reset_index(drop=True, inplace=True)
        return alloc_df

    def build_train_test_datasets(self, model_data_df, train_test_size_params_dict):
        """Build the train and test dataframes.

        Args:
            model_data_df (pd.DataFrame):
            train_test_size_params_dict (dict):

        Returns:
            Dictionary containing train and test dataframes.
        """
        artist_train_data_df, artist_test_data_df = self._build_artist_datasets(
            train_test_size_params_dict["artist_test_size"], model_data_df
        )
        track_train_data_df, track_test_data_df = self._build_track_datasets(
            train_test_size_params_dict["track_test_size"], artist_train_data_df
        )
        train_data_df, time_test_data_df = self._build_time_datasets(
            train_test_size_params_dict["time_track_test_size"],
            train_test_size_params_dict["time_test_size"],
            track_train_data_df,
        )
        train_test_data_dict = {
            "artist_test_data_df": artist_test_data_df,
            "track_test_data_df": track_test_data_df,
            "time_test_data_df": time_test_data_df,
            "train_data_df": train_data_df,
        }

        return train_test_data_dict

    def build_inference_data_dict(self, data_df):
        """Build data used in inference.

        Args:
            data_df (pd.Dataframe): Training data.

        Returns:
            Dictionary containing data for inference.
        """
        num_tracks = data_df.drop_duplicates("sibling_id").shape[0]
        num_artists = data_df.drop_duplicates("artist_name").shape[0]
        artist_mapping_dict = self.build_artist_dict(data_df)
        data_df["artist_name_index"] = data_df["artist_name"].apply(
            lambda row: artist_mapping_dict[row]
        )

        track_mapping_dict = self.build_track_dict(data_df)
        data_df["sibling_id_index"] = data_df["sibling_id"].apply(
            lambda row: track_mapping_dict[row]
        )

        inference_data_dict = {
            "artists_count": num_artists,
            "tracks_count": num_tracks,
            "obs_to_track_dict": [int(v) for v in data_df["sibling_id_index"]],
            "track_to_artist_dict": [
                int(v)
                for v in data_df.drop_duplicates("sibling_id_index")[
                    "artist_name_index"
                ]
            ],
            "week": [int(v) for v in data_df["weeks_since_release"]],
            "stream": [int(v) for v in data_df["stream_count"]],
            "ad_spend": [int(v) for v in np.zeros(data_df.shape[0])],
        }

        return inference_data_dict

    def _artist_atop_model_data(self, artist_name, model_data_df):
        """Move data for the requested artist to the top of the model data.

        Args:
            artist_name (str): Requested artist.
            model_data_df (pd.DataFrame):

        Returns:
            Dataframe containing all modeling data with requested artist on top.
        """
        artist_msk = model_data_df["artist_name"] == artist_name
        model_data_df = pd.concat(
            [model_data_df[artist_msk], model_data_df[~artist_msk]]
        )

        return model_data_df

    def build_artist_dict(self, data_df):
        """Build dictionary of artist names and indexes based on training data.

        Returns:
            Dictionary of artist names/indexes.
        """
        data_df["artist_name_index"] = preprocessing.LabelEncoder().fit_transform(
            data_df["artist_name"]
        )

        return dict(zip(data_df["artist_name"], data_df["artist_name_index"]))

    def build_track_dict(self, data_df):
        """Build dictionary of track names and indexes based on training data.

        Returns:
            Dictionary of track names/indexes.
        """
        data_df["sibling_id_index"] = preprocessing.LabelEncoder().fit_transform(
            data_df["sibling_id"]
        )

        return dict(zip(data_df["sibling_id"], data_df["sibling_id_index"]))

    def _build_artist_datasets(self, artist_test_size, model_data_df):
        """Build dataframe of artist test data.

        artist_test_size (float): Fraction of data to assign to test set.
        model_data_df (pd.DataFrame):

        Returns:
            Dataframes for artist test data and remaining training data.
        """
        artist_name_index_list = list(model_data_df["artist_name"].drop_duplicates())
        num_test_artists = math.ceil(len(artist_name_index_list) * artist_test_size)

        artist_name_index_train_list = artist_name_index_list[
            : len(artist_name_index_list) - num_test_artists
        ]
        msk = model_data_df["artist_name"].isin(artist_name_index_train_list)
        artist_train_data_df = model_data_df[msk]

        artist_name_index_test_list = artist_name_index_list[-num_test_artists:]
        msk = model_data_df["artist_name"].isin(artist_name_index_test_list)
        artist_test_data_df = model_data_df[msk]

        return artist_train_data_df, artist_test_data_df

    def _build_track_datasets(self, track_test_size, artist_train_data_df):
        """Build dataframe of track test data for artists in the training data.

        Args:
            track_test_size (float)
            artist_train_data_df (pd.DataFrame)

        Returns:
            Dataframes for track test data and remaining training data.
        """
        sibling_id_index_list = list(
            artist_train_data_df["sibling_id"].drop_duplicates()
        )
        num_test_tracks = math.ceil(len(sibling_id_index_list) * track_test_size)

        sibling_id_index_train_list = sibling_id_index_list[
            : len(sibling_id_index_list) - num_test_tracks
        ]
        track_train_data_df = artist_train_data_df[
            artist_train_data_df["sibling_id"].isin(sibling_id_index_train_list)
        ]

        sibling_id_index_test_list = sibling_id_index_list[-num_test_tracks:]
        track_test_data_df = artist_train_data_df[
            artist_train_data_df["sibling_id"].isin(sibling_id_index_test_list)
        ]

        return track_train_data_df, track_test_data_df

    def _build_time_datasets(
        self, time_track_test_size, time_test_size, track_train_data_df
    ):
        """Build dataframe of temporal test data for tracks in the training data.

        Args:
            time_track_test_size (float):
            time_test_size (float):
            track_train_data_df (pd.DataFrame):

        Returns:
            Dataframes for temporal test data and remaining training data.
        """
        sibling_id_index_list = list(
            track_train_data_df["sibling_id"].drop_duplicates()
        )
        num_test_tracks = math.ceil(len(sibling_id_index_list) * time_track_test_size)
        sibling_id_index_train_list = sibling_id_index_list[
            : len(sibling_id_index_list) - num_test_tracks
        ]
        sibling_id_index_test_list = sibling_id_index_list[-num_test_tracks:]
        time_test_data_df_indexes_list = []
        for s in sibling_id_index_test_list:
            sibling_index_msk = track_train_data_df["sibling_id"] == s
            max_weeks_since_release = track_train_data_df[sibling_index_msk][
                "weeks_since_release"
            ].max()
            sibling_msk = track_train_data_df["sibling_id"] == s
            weeks_since_release_msk = track_train_data_df[
                "weeks_since_release"
            ] >= math.ceil(max_weeks_since_release * (1 - time_test_size))
            time_msk = sibling_msk & weeks_since_release_msk
            time_test_data_df_indexes = track_train_data_df[time_msk].index
            time_test_data_df_indexes_list.extend(list(time_test_data_df_indexes))

        time_train_msk = track_train_data_df.index.isin(time_test_data_df_indexes_list)
        time_train_data_df = track_train_data_df.loc[~time_train_msk]
        time_test_data_df = track_train_data_df.loc[time_train_msk]

        return time_train_data_df, time_test_data_df

    def _train_test_size_params_dict(self):
        """Parameters for fraction of data to include to remove for test sets.

        Returns:
            Dictionary containing parameters.
        """
        train_test_size_params_dict = {
            "artist_test_size": 0.2,
            "track_test_size": 0.2,
            "time_track_test_size": 0.2,
            "time_test_size": 0.2,
        }

        return train_test_size_params_dict

    def _track_to_max_weeks(self, train_data_df):
        """Build dictionary of the highest weeks since release, for each sibling id.

        train_data_df (pd.DataFrame):

        Returns:
            Dictionary containing weeks since release for each sibling id.
        """
        track_to_max_weeks = (
            train_data_df.groupby("sibling_id")
            .agg({"weeks_since_release": "max"})
            .to_dict()["weeks_since_release"]
        )

        return track_to_max_weeks
