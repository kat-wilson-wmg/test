import time
import requests
import pandas as pd


def _build_playlist_req(forecast_request_dict):
    playlist_req_dict = {}
    playlist_req_dict["weeks"] = "52"
    comps = [str(sib_id) for sib_id in forecast_request_dict["COMPS"]]
    playlist_req_dict["sibling_ids"] = ",".join(comps)
    playlist_req_dict["dsps"] = ",".join(forecast_request_dict["DSP"])
    playlist_req_dict["artist_name"] = forecast_request_dict["ARTIST_NAME"]
    return playlist_req_dict


def _build_playlist_api_dict(playlist_req_dict):
    playlist_api_call_dict = {}
    dependencies = ["simplejson", "gremlinpython", "snowflake-sqlalchemy", "pykrige"]
    playlist_api_call_dict["dependencies"] = dependencies
    playlist_api_call_dict["run_path"] = "/Repos/DEVELOP PL/playlist-app/runner"
    playlist_api_call_dict["request"] = playlist_req_dict

    return playlist_api_call_dict


def _call_dbricks_api(playlist_api_call_dict):
    url = "http://3.233.92.190:8080/databricks/run/submit"
    json = playlist_api_call_dict
    response = requests.post(url=url, json=json)
    if response.status_code == 200:
        response_dict = response.json()
        return response_dict["run_id"]
    else:
        return response.status_code


def get_dbricks_run_id(forecast_request_dict):
    playlist_req_dict = _build_playlist_req(forecast_request_dict)
    playlist_api_call_dict = _build_playlist_api_dict(playlist_req_dict)
    run_id = _call_dbricks_api(playlist_api_call_dict)
    return run_id


def get_task_run_id(run_id):
    url = f"http://3.233.92.190:8080/databricks/run/{run_id}"
    respone = requests.get(url)
    response_dict = respone.json()
    tasks = response_dict["tasks"][0]
    task_run_id = tasks["run_id"]
    return task_run_id


def check_playlist_response(task_run_id):
    is_terminated = False
    response_dict = {}
    while not is_terminated:
        url = f"http://3.233.92.190:8080/databricks/run/output/{task_run_id}"
        response = requests.get(url)
        response_dict = response.json()
        response_state = response_dict["metadata"]["state"]
        terminate_msg = response_state["life_cycle_state"]
        is_terminated = terminate_msg == "TERMINATED"
        if not is_terminated:
            time.sleep(120)
    return response_dict


def get_playlist_score(forecast_request_dict):
    run_id = get_dbricks_run_id(forecast_request_dict)
    task_run_id = get_task_run_id(run_id)
    res = check_playlist_response(task_run_id)
    if res != "Failed":
        res_json = res["notebook_output"]["result"]
        df = pd.read_json(res_json)
        return process(df)
    else:
        return None


def process(df):
    df = df[["sibling_id", "t", "rt"]]
    df.columns = ["sibling_id", "DATE_KEY", "pl_score"]
    df["DSP"] = "Spotify"
    df = df.drop_duplicates(["sibling_id", "DATE_KEY"])
    return df
