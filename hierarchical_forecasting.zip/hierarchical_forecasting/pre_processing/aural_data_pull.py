import datetime as dt
import json
import requests
import time



def execute(request):
    """Pull data from the aural features api.

    Args:
        request (dict):
    
    Returns:
        pd.DataFrame: Contains aural features result data.
    """
    aural_request_dict = request["COMPS"]
    run_id = _submit_databricks_run(aural_request_dict)
    task_run_id = _get_task_run_id(run_id)
    response_dict = _response_dict(task_run_id)
    result_df = _extract_result(response_dict)

    return result_df


def _submit_databricks_run(aural_request_dict):
    """Call the databricks api with the requst comps and get the run id.

    Args:
        aural_request_dict (dict):

    Returns:
        int: Databricks aural features run id.
    """
    aural_features_call_dict = _build_api_dict(aural_request_dict)
    run_id = _call_databricks_api(aural_features_call_dict)

    return run_id


def _build_api_dict(aural_features_req_dict):
    """Build dictionary for calling music_feature_product databricks api.

    Args:
        aural_request_dict (dict):
    
    Returns:
        dict: Contains data for calling music_feature_product databricks api.
    """
    aural_features_call_dict = {}
    dependencies = [
        "pandas",
        "sklearn",
        "kneed",
        "scikit-learn",
        "python-dotenv",
        "snowflake-connector-python",
        "boto3",
        "pytest",
    ]
    aural_features_call_dict["dependencies"] = dependencies
    aural_features_call_dict[
        "run_path"
    ] = "/Repos/DEVELOP MF/music_feature_product/runner"
    aural_features_call_dict["request"] = aural_features_req_dict

    return aural_features_call_dict


def _call_databricks_api(aural_features_call_dict):
    """Call the music_feature_product api.

    Args:
        aural_features_call_dict (dict):

    Returns:
        int: run_id for the submitted aural features api call.
    """
    url = "http://3.233.92.190:8080/databricks/run/submit"
    json = aural_features_call_dict
    response = requests.post(url=url, json=json)
    response_dict = response.json()
        
    run_id = response_dict["run_id"]

    return run_id


def _get_task_run_id(run_id):
    """Get the task_run_id for the given run_id.

    Args:
        run_id (int):

    Returns:
        int: task_run_id which 
    """
    url = f"http://3.233.92.190:8080/databricks/run/{run_id}"
    response = requests.get(url)
    response_dict = response.json()
    tasks = response_dict["tasks"][0]
    task_run_id = tasks["run_id"]

    return task_run_id


def _response_dict(task_run_id):
    """Get the aural features api response.

    Args:
        task_run_id (int):

    Returns:
        dict: Contains the aural features api response.
    """
    start_time = dt.datetime.now()
    is_terminated = False
    response_dict = {}
    while not is_terminated:
        url = f"http://3.233.92.190:8080/databricks/run/output/{task_run_id}"
        response = requests.get(url)
        response_dict = response.json()
        response_state = response_dict["metadata"]["state"]
        terminate_msg = response_state["life_cycle_state"]
        is_terminated = terminate_msg == "TERMINATED"
        if not is_terminated:
            time.sleep(30)
        print("terminate", response_state["life_cycle_state"])

        time_since_start_sec = (dt.datetime.now() - start_time).total_seconds()
        if time_since_start_sec > 60*10:
            break
    
    return response_dict

def _extract_result(response_dict):
    """Extract the result string to a dictionary.

    Args:
        response_dict (dict):
        
    Returns:
        pd.DataFrame: Contains the response result aural features data.
    """
    result_str = response_dict['notebook_output']['result']
    result_str = result_str.replace("\'", "\"")
    result_dict = json.loads(result_str)
    result_df = pd.DataFrame(output_result_dict['aural_data'])

    return result_df
