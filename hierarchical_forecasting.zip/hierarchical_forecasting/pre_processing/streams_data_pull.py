import json
import logging

from hierarchical_forecasting.utils.countries import countries
from hierarchical_forecasting.utils.notification import Notification

from pyspark.sql import SparkSession

spark = SparkSession.builder.getOrCreate()
import pyspark.sql.functions as F



def execute_streams_query(request):
    """Pull streams data for the request.

    Args:
        request (dict):

    Returns:
        pd.DataFrame: Streams data for the request.
    """
    if request.get("AFFINITY_ARTIST", "") == "":
        country_codes = _country_codes(request)
        data_df = _execute_streams_query_without_affinity_artist(request, country_codes)
        _notification_without_affinity_artist(data_df)
    else:
        query_str = _build_streams_query_with_affinity_artist(request)
        secrets_dict = _pull_snowflake_secrets()
        data_df = _execute_streams_query_with_affinity_artist(query_str, secrets_dict)

    return data_df


def _country_codes(request):
    """Extract country codes from request for streams query.

    Args:
        request (dict):

    Returns:
        list: Country codes from request.
    """
    if request["COUNTRY_CODE"] == ["Global"]:
        country_codes = countries().list_of_country_codes()
    else:
        country_codes = request["COUNTRY_CODE"]

    return country_codes


def _execute_streams_query_without_affinity_artist(request, country_codes):
    """Pull streams data for comps, without an affinity artist.

    Args:
        request (dict):
        country_codes (list):

    Returns:
        pd.DataFrame: Streams data, without an affinity artist.
    """
    data_df = (
        spark.table("WMG.stream_daily")
        .where(
            F.col("COUNTRY_CODE").isin(country_codes)
            & F.col("DSP").isin(request["DSP"])
            & F.col("SIBLING_ID").isin(request["COMPS"])
        )
        .cache()
        .toPandas()
    )

    return data_df


def _notification_without_affinity_artist(data_df):
    """Send notification email if there is not enough streams data.

    Args:
        data_df (pd.DataFrame):
    """
    if len(data_df) == 0:
        try:
            logging.warning(
                notification.send_email_fail(
                    request["CLIENT_EMAIL"],
                    "We could not find enough data to process your request!",
                )
            )
        except:
            logging.warning("Notification Failed")


def _build_streams_query_with_affinity_artist(request):
    """Build streams query with an affinity artist.

    Args:
        request (dict):

    Returns:
        str: Streams with affinity artist query string.
    """
    affinity_artist_str = request["AFFINITY_ARTIST"]
    country_codes_str = _country_codes_where_clause_str(request)
    request_comps_str = _request_comps_where_clause_str(request)
    query_str = f"""
        SELECT     
            fact.date_key,
            fact.product_key,
            fact.country_code,
            fact.customer_key,
            consumer.artist_display_name AS audience_artist,
            ANY_VALUE(customer.customer_name) AS dsp,
            ANY_VALUE(country.country_name) AS country,
            ANY_VALUE(artist.artist_key) AS artist_key,
            ANY_VALUE(artist.display_name) AS artist_name,
            ANY_VALUE(artist2.display_name) AS product_artist_name,
            ANY_VALUE(asset.asg_grouping_title) AS sibling_title,
            ANY_VALUE(asset.sibling_id) AS sibling_id,
            ANY_VALUE(asset.family_id) AS family_id,
            MIN(product.first_global_release_date) AS product_release_date,
            SUM(fact.stream_count) AS stream_count
        FROM
            df_prod.dap.dim_product product
            INNER JOIN df_prod.dap.fact_audio_streaming fact ON product.product_key = fact.product_key
            INNER JOIN data_science_sandbox.camille_t.forecast_cons_fact consumer ON fact.consumer_id = consumer.consumer_id
            INNER JOIN df_prod.dap.rel_product_asset_sibling asset ON asset.product_key = fact.product_key
            INNER JOIN df_prod.dap.dim_artist artist ON asset.asg_primary_artist_id = artist.artist_key
            INNER JOIN df_prod.dap.dim_artist artist2 ON product.ARTIST_ID = artist2.artist_key
            INNER JOIN df_prod.dap.dim_customer customer ON customer.customer_key = fact.customer_key
            INNER JOIN df_prod.dap.dim_country country ON country.country_code = fact.country_code
        WHERE
            consumer.artist_display_name = '{affinity_artist_str}' AND
            fact.date_key > '01/01/2019' AND
            fact.date_key <= current_date() AND
            product.first_global_release_date > '01/01/2018' AND
            product.first_global_release_date < current_date() AND
            product.first_global_release_date <= fact.date_key AND
            {country_codes_str}
            customer.customer_name IN ('Spotify') AND
            asset.sibling_id IN ({request_comps_str})
        GROUP BY
            1, 2, 3, 4, 5
        HAVING SUM(fact.stream_count) > 10
    """

    return query_str


def _country_codes_where_clause_str(request):
    """Build string for country codes in query where clause.

    Args:
        request (dict):

    Returns:
        str: Country codes for where clause.
    """
    if "Global" in request["COUNTRY_CODE"]:
        country_codes_str = ""
    else:
        country_codes_str = ("', '").join(request["COUNTRY_CODE"])
        country_codes_str = f"'{country_codes_str}'"
        country_codes_str = f"country.country_code IN ({country_codes_str}) AND"

    return country_codes_str


def _request_comps_where_clause_str(request):
    """Build string for request comps sibling ids for where clause.

    Args:
        request (dict):

    Returns:
        str: Request comps sibling ids str for where clause.
    """
    request_comps_str = [str(r) for r in request["COMPS"]]
    request_comps_str = (", ").join(request_comps_str)

    return request_comps_str


def _pull_snowflake_secrets():
    """Pull snowflake secrets data.        

    Returns:
        dict: Secrets for pulling snowflake data.
    """
    secret_name = "snowflake_service_acct"
    region_name = "us-east-1"
    session = boto3.Session()

    client = session.client(service_name="secretsmanager", region_name=region_name)

    get_secret_value_response = client.get_secret_value(SecretId=secret_name)
    secrets = get_secret_value_response["SecretString"]

    secrets_dict = json.loads(secrets)

    return secrets_dict


def _execute_streams_query_with_affinity_artist(query_str, secrets_dict):
    """Pull streams data for comps, without an affinity artist.

    Args:
        query_str (str):
        secrets_dict (dict):

    Returns:
        pd.DataFrame: Streams data, with an affinity artist.
    """
    data_df = (
        spark.read.format("snowflake")
        .option("sfUrl", "https://wmg-datalab.snowflakecomputing.com")
        .option("sfUser", secrets_dict["username"])
        .option("sfPassword", secrets_dict["password"])
        .option("sfDatabase", "DF_PROD")
        .option("sfSchema", "DAP")
        .option("sfWarehouse", "SYSTEMACCOUNT")
        .option("query", query_str)
        .load()
        .withColumn("PRODUCT_KEY", F.col("PRODUCT_KEY").cast(T.IntegerType()))
        .withColumn("CUSTOMER_KEY", F.col("CUSTOMER_KEY").cast(T.IntegerType()))
        .withColumn("sibling_id", F.col("sibling_id").cast(T.IntegerType()))
        .withColumn("STREAM_COUNT", F.col("STREAM_COUNT").cast(T.IntegerType()))
        .toPandas()
    )

    return data_df

