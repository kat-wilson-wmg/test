from pyspark.sql import SparkSession

spark = SparkSession.builder.getOrCreate()
import pyspark.sql.functions as F

def execute_ad_spend_query(request):
    """Pull Wavo ad spend data for comps.
    
    Returns:
        pd.Dataframe: Ad spend data for comps.
    """
    ad_spend_df = (
        spark.table("WMG.wavo")
        .where(F.col("SIBLING_ID").isin(request["COMPS"]))
        .cache()
        .toPandas()
    )

    return ad_spend_df


def has_ad_spend_data(ad_spend_df):
    """Flag for whether there is ad spend data.

    Args:
        ad_spend_df (pd.DataFrame):

    Returns:
        bool: Flag for if there is ad spend data in the comps.
    """
    if ad_spend_df is None:
        return False
    if ad_spend_df.shape[0] == 0:
        return False
    return True