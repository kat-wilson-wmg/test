def process(request):
    """Fixes the formatting of the request

   Args: request dictionary

   Return: modified request dictionary
   """
    request["DSP"] = request["DSP"]
    request["COUNTRY_CODE"] = request["COUNTRY_CODE"]
    request["COMPS"] = request["COMPS"]
    request["ADSPEND"] = request["ADSPEND"]
    request["TRACK_ID"] = int(request["TRACK_ID"])
    if request["TRACK_ID"] != 0:
        request["COMPS"].append(request["TRACK_ID"])
    if request["TRACK_ID"] == 0:
        request["TRACK_ID"] = None
    request['BACKTEST_WINDOW'] = int(request.get('BACKTEST_WINDOW',0))
    request['DISCOUNT_FACTOR'] = float(request.get('DISCOUNT_FACTOR',0))
    request['COMPS_COUNT'] = int(request.get('COMPS_COUNT',10))
    return request



def mock_request(name = 'John Smith', email = ''):
    """Creates a mock request

    Return: request dictionary
    """
    request_dict = {
        "REQUEST_ID": "0",
        "CLIENT_NAME": name,
        "CLIENT_EMAIL": email,
        "ARTIST_NAME": "Roddy Ricch",
        "TRACK_NAME": "Late At Night",
        "TRACK_ID": 4237493,
        "DISCOUNT_FACTOR": 0.05,
        "BACKTEST_WINDOW": 5,
        "FORECAST_HORIZON": 1,
        "COMPS_COUNT": 10,
        "AFFINITY_ARTIST": "",
        "COUNTRY_CODE": ["US"],
        "DSP": ["Spotify", "Apple Music"],
        "ADSPEND": [1000., 10000., 20000., 5000., 400.],
        "COMPS": [
            4277837,
            4274861,
            4282903,
            4268325,
            3304572,
            3437080,
            3396873,
            3366705,
            3609560,
            3110086,
            3616358,
            3625156,
            3929730,
            2908735,
            3651488,
            2739392,
            3690245,
            1456533,
            436832,
            811185,
            343440,
            581780,
            356618,
            137197,
            447878,
            450674,
            456931,
            125089,
            800670,
            44507,
            906213,
            131815,
            833303,
            833324,
            834796,
            46190,
            714454,
            15507,
            440608,
            468311,
            467183,
            22657,
            388774,
            679317,
            426058,
            4023962,
            4062398,
            4062121,
            4069231,
            4072662,
            4075934,
            511816,
            662524,
            4237493
        ],
    }
    return request_dict