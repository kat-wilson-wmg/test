from hierarchical_forecasting.utils.notification import Notification


def send(request):
    """Send request acknowledgement email.

    Args:
        request (dict):
    """
    notification = Notification()
    notification.send_email(request["CLIENT_EMAIL"], _html_msg(request))


def _html_msg(request):
    """Makes query string.

        Args:
            request (dict):
    """

    html_msg = f"""
    <html>
    <body>
    <p>Hi {request['CLIENT_NAME']},</p>

    <p>We recieved your forecast request. We will send the results in another email. In case the results email didn't arrive after 4 hours from receiving this notification, please reach out to us.</p>

    <p>Below is your request details:</p>
    </br>
    <code>{request}</code>
    </br></br>

    <p>You can also monitor your request through our website: http://35.168.220.252:2222</p>

    Thank you,</br></br>
    Data Science @ WMG
    </body>
    </html>
    """

    return html_msg
