import pandas as pd
import numpy as np

def similar_streams_filter(data_df, request_sibling_id, n_similar_comps):
    days_since_release = _days_since_release(data_df, request_sibling_id)
    near_release_dates_data_df = _data_near_release_dates(
        data_df, days_since_release
    )

    n_comps = near_release_dates_data_df.drop_duplicates("sibling_id").shape[0]
    if n_comps < n_similar_comps:
        output_data_df = data_df.copy()
    else:
        output_data_df = _mean_daily_streams_filter(
            data_df, near_release_dates_data_df, request_sibling_id, n_similar_comps
        )

    return output_data_df


def _data_near_release_dates(data_df, days_since_release):
    data_df["DATE_KEY"] = pd.to_datetime(data_df["DATE_KEY"])
    data_df["PRODUCT_RELEASE_DATE"] = pd.to_datetime(data_df["PRODUCT_RELEASE_DATE"])
    near_release_dates_msk = data_df["DATE_KEY"] < data_df[
        "PRODUCT_RELEASE_DATE"
    ] + pd.Timedelta(days=days_since_release)
    near_release_dates_data_df = data_df[near_release_dates_msk]

    return near_release_dates_data_df


def _days_since_release(data_df, request_sibling_id):
    request_msk = data_df["sibling_id"] == request_sibling_id
    product_release_date_dt = data_df[request_msk]["PRODUCT_RELEASE_DATE"].values[0]
    time_delta = np.datetime64('now') - product_release_date_dt
    days_since_release = time_delta.astype('timedelta64[D]')
    days_since_release_int  = days_since_release / np.timedelta64(1, 'D')
    return days_since_release_int


def _mean_daily_streams_filter(
    data_df, near_release_dates_data_df, request_sibling_id, n_similar_comps
):
    cols = ["sibling_id", "STREAM_COUNT"]
    near_release_dates_data_df = near_release_dates_data_df[cols]

    grps = near_release_dates_data_df.groupby("sibling_id")
    grouped_stream_df = grps.agg({"STREAM_COUNT": "mean"})
    grouped_stream_df.reset_index(inplace=True)

    request_msk = grouped_stream_df["sibling_id"] == request_sibling_id
    total_stream_req_track = grouped_stream_df[request_msk]
    total_stream_req_track = total_stream_req_track["STREAM_COUNT"].values[0]

    grouped_stream_df["diff_from_request_stream"] = (
        grouped_stream_df["STREAM_COUNT"] - total_stream_req_track
    ).abs()

    similar_comps_df = grouped_stream_df.nsmallest(
        n_similar_comps, "diff_from_request_stream"
    )

    output_data_df = data_df.merge(
        similar_comps_df["sibling_id"], how="inner", on="sibling_id"
    )

    return output_data_df
