import jax
import jax.numpy as jnp
import numpy as np
import pandas as pd
import numpyro
import arviz as az
from numpyro.infer import Predictive
from numpyro.handlers import seed, trace
from jax import random, vmap
from jax.scipy.special import logsumexp
from hierarchical_forecasting.modeling.optimization import AdSpendOptimization

class InferenceModel:
    def __init__(
            self,
            model,
            num_samples,
            num_warmup,
            num_chains=1,
            chain_method="parallel",
            progress_bar=False,
    ):
        self.prng_key = jax.random.PRNGKey(2)
        self.forecast_model_instance = model
        self.num_samples = num_samples
        self.num_warmup = num_warmup
        self.num_chains = num_chains
        self.chain_method = chain_method
        self.progress_bar = progress_bar

    def fit(self, X, y, tags,data_processing_instance):

        self.data_processing_instance = data_processing_instance
        self.tags=tags
        self.present_week = pd.DataFrame(y[-1,:,0,:]).apply(pd.Series.last_valid_index)

        nuts_kernel = numpyro.infer.NUTS(self.forecast_model_instance.model)
        mcmc = numpyro.infer.MCMC(
            nuts_kernel,
            num_samples=self.num_samples,
            num_warmup=self.num_warmup,
            num_chains=self.num_chains,
            chain_method=self.chain_method,
            progress_bar=self.progress_bar,
        )

        mcmc.run(self.prng_key, X=jnp.array(X), y=jnp.array(y), tags=tags)
        self.samples = mcmc.get_samples()
        self.arviz_data = az.from_numpyro(mcmc)
        self.last_state = mcmc.last_state

    def _posterior_predictive(self, X, tags, samples):
        rng_key, rng_key_ = random.split(self.prng_key)
        predictive = Predictive(self.forecast_model_instance.model, samples)
        output_posterior_samples = predictive(rng_key_, X=X, y=None, tags=tags)
        return output_posterior_samples

    def log_likelihood(self, X, y, tags):
        obs_node = trace(seed(self.forecast_model_instance.model, self.prng_key)).get_trace(X, y, tags)['streams']
        log_prob = obs_node['fn'].log_prob(obs_node['value'])
        return np.where(np.isnan(y), np.nan, log_prob)

    def log_pred_density(self, X, y, tags, samples):
        n = list(samples.values())[0].shape[0]
        log_lk_fn = vmap(lambda rng_key, params: self.log_likelihood(X, y, tags))
        log_lk_vals = log_lk_fn(random.split(prng_key, n), samples)
        log_lk_vals = jnp.nan_to_num(log_lk_vals)
        return (logsumexp(log_lk_vals, 0) - jnp.log(n)).sum()

    def _tensorify_alloc_matrix(self, opt_alloc):
        dims = self.data_processing_instance.dims
        present_week = self.present_week
        max_week = np.max(present_week)
        Z = np.zeros((dims.tracks, dims.weeks, dims.days, dims.features))
        horizon = opt_alloc.shape[0]
        try:
            Z[-1, max_week:max_week + horizon, :, :dims.channels] = opt_alloc
        except:
            Z[-1, : horizon, :, :dims.channels] = opt_alloc
            print("Week 1 of planning equals week 1 after release, is this a new release?")
        return Z

    def run_optimization(self, budget, posterior_samples):
        beta = posterior_samples['beta_track'][:, -1, 0, 0, :, :]
        kappa = posterior_samples['kappa_track'][:, -1, 0, 0, :, :]
        m = posterior_samples['m_track'][:, -1, 0, :, :, :]
        beta_median = np.median(beta, axis=0)
        kappa_median = np.median(kappa, axis=0)
        m_median = np.median(m, axis=0)
        opt = AdSpendOptimization.optimal_allocation(m_median, beta_median, kappa_median, budget)
        return opt

    def optimization_wrapper(self, budget,posterior_samples):
        opt_alloc = self.run_optimization(budget,posterior_samples)
        try:
            output = self._tensorify_alloc_matrix(opt_alloc)
            return output, opt_alloc
        except:
            ad_impact = posterior_samples['ad_effect_var']
            n_channels = ad_impact.shape[-1]
            b = np.array(budget)
            horizon = b.shape[0]
            b = b.reshape((horizon,1,1))
            opt_alocc = np.tile(b // (n_channels + 7), (1, 7, n_channels))
            return self._tensorify_alloc_matrix(opt_alloc), opt_alocc

    def posterior_predictive(self, X):
        track_samples = self._posterior_predictive(X, self.tags, self.samples)
        return track_samples

    def predict(self, X):
        track_samples = self._posterior_predictive(X, self.tags, self.samples)['streams']
        return track_samples[...,-1] * self.data_processing_instance.denom

    def _rmse(self,y_hat, y_pred_samples):
        y_pred = np.median(y_pred_samples, axis=0)
        norm = np.sum(np.nan_to_num(y_hat - y_pred) ** 2)
        n = np.sum(~np.isnan(y_hat))
        return np.sqrt(norm / n)

    def _mape(self,y_hat, y_pred_samples):
        y_pred = np.maximum(np.median(y_pred_samples, axis=0), 0)
        rel_diff = np.abs(np.divide(y_hat - y_pred, y_hat))
        rel_diff = rel_diff[np.where(~np.isnan(rel_diff))]
        return np.mean(rel_diff) * 100

    def _score(self, X, y_test, func):
        y_pred_samples = self.predict(X)
        return func(y_test * self.data_processing_instance.denom, y_pred_samples)

    def test_scores(self, X, y_test, func):

        return self._score(X, y_test, func)

        # score_dict['total'] = self._score(X,y,func)
        #
        # y_new_rel = np.ones_like(y) * np.nan
        # X_new_rel = np.ones_like(X) * np.nan
        # new_rels = np.where(tags['track_level'] == 0)[0]
        # y_new_rel[new_rels, :, :, :] = y[new_rels, :, :, :]
        # X_new_rel[new_rels, :, :, :] = X[new_rels, :, :, :]
        # score_dict['artist_level'] = self._score(X_new_rel, y_new_rel, func)
        #
        # a = np.sum(~np.isnan(y), axis=(-3, -2, -1)) > 0
        # A = np.where(a)[0]
        # B = np.where(tags['track_level'] == 1)[0]
        # back_tests = np.intersect1d(A,B)
        # y_final_weeks = np.ones_like(y) * np.nan
        # X_final_weeks = np.ones_like(X) * np.nan
        # y_final_weeks[back_tests, :, :, :] = y[back_tests, :, :, :]
        # X_final_weeks[back_tests, :, :, :] = X[back_tests, :, :, :]
        # score_dict['track_level'] = self._score(X_new_rel, y_new_rel, func)


# COMMAND ----------
