import datetime

import numpy as np

from hierarchical_forecasting.modeling.dimensions import Dimensions
from hierarchical_forecasting.modeling.plates import Plates
import jax
import jax.numpy as jnp
import numpyro.distributions as dist
import numpyro
from numpyro.infer.reparam import TransformReparam


class HierarchicalForecastModel:
    def __init__(self, delta):
        self.delta = delta

    def model(self, X, y, tags):
        """Contains a hierarchical Bayesian model with adspend for inference with numpyro.
        Args:
            X (array with 4 dimensions): Contains feature data values
            y (array with 4 dimensions): Contains targets data values - None for prediction
            tags (dict): Contains track pooling data
        Returns:
            Numpyro sample from the stochastic function of track stream counts
        """
        # Notes:
        self.eps = 1e-15  # epsilon
        self.weeks_denom = 52.0

        # dimensions and plates
        dims = tags["dimensions"]
        plates = Plates(dims)

        self.dims = dims

        # parameters
        shape_vars = ["k_log", "theta_log", "r_log"]
        magnitude_vars = ["m_log"]
        ad_spend_vars = ["beta_sqrt", "kappa_sqrt"]
        playlist_vars = ["p_sqrt"]

        # top level parameters
        with plates.dsps:
            top_level_params_dict = self._top_level_params(
                shape_vars,
                magnitude_vars,
                ad_spend_vars,
                playlist_vars,
                plates.days,
                plates.channels,
                dims,
            )

        with plates.tracks, plates.dsps:
            track_level_params_dict = self._track_level_params(
                top_level_params_dict,
                tags,
                shape_vars,
                magnitude_vars,
                ad_spend_vars,
                playlist_vars,
                plates.days,
                plates.channels,
                dims,
            )

        helper_params_dict = self._helper_params(
            top_level_params_dict,
            track_level_params_dict,
            ad_spend_vars,
        )

        with plates.tracks, plates.weeks, plates.dsps, plates.days:
            streams_sample = self._obs_level_params(
                X,
                y,
                top_level_params_dict,
                track_level_params_dict,
                helper_params_dict,
                dims,
            )

        return streams_sample

    def _top_level_params(
        self,
        shape_vars,
        magnitude_vars,
        ad_spend_vars,
        playlist_vars,
        plate_days,
        plate_channels,
        dims,
    ):

        top_level_params_dict = {"means_dict": {}, "errors_dict": {}}
        for var in shape_vars + playlist_vars:
            k = var + "_top"
            one_vector = jnp.ones((1, 1, 1, dims.dsps, 1))
            v = numpyro.sample(k, dist.Normal(1.0 * one_vector, 2.0 * one_vector))
            top_level_params_dict["means_dict"][k] = v
        with plate_days:
            for var in magnitude_vars:
                k = var + "_top"
                one_vector = jnp.ones((1, 1, dims.days, dims.dsps, 1))
                week_loc = top_level_params_dict["means_dict"]["r_log_top"]
                v = self._level_sample(
                    k, week_loc * one_vector, one_vector, 0.0 * one_vector, one_vector
                )
                top_level_params_dict["means_dict"][k] = v
        with plate_channels:
            top_level_params_dict = self._top_level_params_by_channel(
                ad_spend_vars, top_level_params_dict, dims
            )
        for var in shape_vars + playlist_vars + magnitude_vars:
            k = "sigma_" + var + "_top"
            var_dist = dist.Uniform(0.0, 2.0)
            v = numpyro.sample("sigma_" + var + "_top", var_dist)
            top_level_params_dict["errors_dict"][k] = v
        for var in ad_spend_vars:
            k = "sigma_" + var + "_top"
            var_dist = dist.Uniform(0.0, 2.0)
            v = numpyro.sample("sigma_" + var + "_top", var_dist)
            top_level_params_dict["errors_dict"][k] = v
        return top_level_params_dict

    def _top_level_params_by_channel(self, ad_spend_vars, top_level_params_dict, dims):
        new_top_level_params_dict = top_level_params_dict.copy()
        one_vector = jnp.ones((1, 1, 1, dims.dsps, dims.channels))
        for var in ad_spend_vars:
            k = var + "_top"
            if var == "beta_sqrt":
                v = numpyro.sample(k, dist.Normal(0.4 * one_vector, 0.2 * one_vector))
            else:
                v = numpyro.sample(
                    k, dist.Normal(500.0 * one_vector, 50.0 * one_vector)
                )
            new_top_level_params_dict["means_dict"][k] = v
        return new_top_level_params_dict

    def _track_level_params(
        self,
        top_level_params_dict,
        tags,
        shape_vars,
        magnitude_vars,
        ad_spend_vars,
        playlist_vars,
        plate_days,
        plate_channels,
        dims,
    ):
        track_level_params_dict = {"means_dict": {}}
        upper_level = "top"
        for var in shape_vars + playlist_vars:
            k = var + "_track"
            one_vector = jnp.ones((dims.tracks, 1, 1, dims.dsps, 1))
            upper_level_mean = top_level_params_dict["means_dict"][
                var + f"_{upper_level}"
            ]
            upper_level_error = top_level_params_dict["errors_dict"][
                "sigma_" + var + f"_{upper_level}"
            ]
            v = self._level_sample(
                k, upper_level_mean, upper_level_error, 0.0 * one_vector, one_vector
            )
            track_level_params_dict["means_dict"][k] = v

        with plate_days:
            for var in magnitude_vars:
                k = var + "_track"
                one_vector = jnp.ones((dims.tracks, 1, dims.days, dims.dsps, 1))
                upper_level_mean = top_level_params_dict["means_dict"][
                    var + f"_{upper_level}"
                ]
                upper_level_error = top_level_params_dict["errors_dict"][
                    "sigma_" + var + f"_{upper_level}"
                ]
                v = self._level_sample(
                    k, upper_level_mean, upper_level_error, 0.0 * one_vector, one_vector
                )
                track_level_params_dict["means_dict"][k] = v
        with plate_channels:
            track_level_params_dict = self._track_level_params_by_channel(
                tags,
                top_level_params_dict,
                track_level_params_dict,
                ad_spend_vars,
                dims,
            )
        return track_level_params_dict

    def _track_level_params_by_channel(
        self,
        tags,
        top_level_params_dict,
        track_level_params_dict,
        ad_spend_vars,
        dims,
    ):
        upper_level = "top"

        for var in ad_spend_vars:
            k = var + "_track"
            one_vector = jnp.ones((dims.tracks, 1, 1, dims.dsps, dims.channels))
            upper_level_mean = top_level_params_dict["means_dict"][
                var + f"_{upper_level}"
            ]
            upper_level_error = top_level_params_dict["errors_dict"][
                "sigma_" + var + f"_{upper_level}"
            ]
            v = self._level_sample(
                k,
                upper_level_mean,
                upper_level_error,
                0.0 * one_vector,
                0.01 * one_vector,
            )
            track_level_params_dict["means_dict"][k] = v
        return track_level_params_dict

    def _helper_params(
        self,
        top_level_params_dict,
        track_level_params_dict,
        ad_spend_vars,
    ):
        helper_params_dict = {}

        for k, v in track_level_params_dict["means_dict"].items():
            param_name = k.split("_")
            param_name = "{}_{}".format(param_name[0], "_".join(param_name[2:]))
            if param_name in ["beta_track", "kappa_track", "p_track"]:
                helper_params_dict[param_name] = numpyro.deterministic(
                    param_name, jnp.power(v, 2.0)
                )
            else:
                helper_params_dict[param_name] = numpyro.deterministic(
                    param_name, jnp.exp(v)
                )
        sigma_streams_0 = numpyro.sample("sigma_streams_0", dist.Uniform(0.0, 2.0))
        sigma_0 = numpyro.deterministic("sigma_0", sigma_streams_0)
        sigma_streams = numpyro.deterministic(
            "sigma_streams", helper_params_dict["m_track"] * sigma_0
        )
        helper_params_dict["sigma_streams"] = sigma_streams
        top_level_ad_spend_params = {}
        for param in ad_spend_vars:
            top_level_ad_spend_params[param + "_top_level"] = numpyro.deterministic(
                param + "_top_level",
                top_level_params_dict["means_dict"][param + "_top"],
            )

        return helper_params_dict

    def _obs_level_params(
        self,
        X,
        y,
        top_level_params_dict,
        track_level_params_dict,
        helper_params_dict,
        dims,
    ):

        ad_spend_tensor = jnp.nan_to_num(X[..., : dims.channels])
        end_ix = dims.channels
        playlist_tensor = jnp.nan_to_num(X[..., end_ix : end_ix + dims.dsps])
        end_ix += dims.playlist_feats
        aural_tensor = jnp.nan_to_num(X[..., end_ix : end_ix + dims.aural_feats])

        m_tracks = track_level_params_dict["means_dict"]["m_log_track"]
        shape = self._shape_function(
            helper_params_dict["k_track"],
            helper_params_dict["theta_track"],
            m_tracks,
            dims,
        )
        shape_var = numpyro.deterministic("shape_var", shape)
        ad_effect = self._ad_effect(
            ad_spend_tensor,
            helper_params_dict["beta_track"],
            helper_params_dict["kappa_track"],
            dims,
        )
        ad_effect_var = numpyro.deterministic("ad_effect_var", ad_effect)
        ad_effect_total = jnp.sum(ad_effect_var, axis=-1, keepdims=True)

        p = helper_params_dict["p_track"]
        p_tensor = jnp.tile(p, (1, dims.weeks, dims.days, 1, 1))
        playlist_tensor = playlist_tensor.reshape(
            (dims.tracks, dims.weeks, dims.days, dims.dsps, 1)
        )
        playlist_impact = numpyro.deterministic(
            "playlist_impact", playlist_tensor * p_tensor
        )

        loc_obs = numpyro.deterministic(
            "loc_obs", (shape_var + ad_effect_total + playlist_impact)
        )
        daily_sigmas = helper_params_dict["sigma_streams"]
        scale_obs = numpyro.deterministic(
            "scale_obs", jnp.tile(daily_sigmas, (1, dims.weeks, 1, 1, 1))
        )
        is_observed = True
        observations = None

        discounts = np.power((1 + self.delta), np.arange(dims.weeks))
        discounts = discounts.reshape((1, dims.weeks, 1, 1, 1))
        discounts_tiled = np.tile(
            discounts, (dims.tracks, 1, 7, dims.dsps, 1)
        )
        scale_obs_discounted = scale_obs / discounts_tiled

        if y is not None:
            targets = y.reshape((dims.tracks, dims.weeks, dims.days, dims.dsps, 1))
            is_observed = ~jnp.isnan(targets)
            observations = jnp.where(is_observed, targets, 0.0)
        with numpyro.handlers.mask(mask=is_observed):
            streams = numpyro.sample(
                "streams", dist.Normal(loc_obs, scale_obs_discounted), obs=observations
            )
        return streams

    def _level_sample(
        self, level_param, upper_level_mean, upper_level_error, loc_base, scale_base
    ):
        """Helper function for affine transformation.

        Args:
            level_param (str):
            upper_level_mean (numpyro.sample): additive factor of affine transform
            upper_level_error (numpyro.sample): multiplicative factor of affine transform
            loc_base (float): mean of base normal dist
            scale_base (float): std of the base normal dist

        Returns:
            Numpyro sample for a plate level parameter.
        """
        with numpyro.handlers.reparam(config={level_param: TransformReparam()}):
            affine_transform = dist.transforms.AffineTransform(
                upper_level_mean, upper_level_error
            )
            base_dist = dist.Normal(loc_base, scale_base)
            transformed_distribution = dist.TransformedDistribution(
                base_dist, affine_transform
            )
            level_sample = numpyro.sample(level_param, transformed_distribution)

        return level_sample

    def _shape_function(self, k, theta, m, dims):
        # we use gamma(k,theta) with multiplictive factor m
        week_values = (
            jnp.expand_dims((jnp.arange(dims.weeks) + 1), axis=(-5, -3, -2, -1))
            / self.weeks_denom
        )
        week_matrix = jnp.tile(week_values, (dims.tracks, 1, dims.days, dims.dsps, 1))
        k_matrix = jnp.tile(k, (1, dims.weeks, dims.days, 1, 1))
        theta_matrix = jnp.tile(theta, (1, dims.weeks, dims.days, 1, 1))
        m_matrix = jnp.tile(m, (1, dims.weeks, 1, 1, 1))
        term_0 = m_matrix
        term_1 = (k_matrix - jnp.ones_like(k_matrix)) * jnp.log(week_matrix)
        term_2 = -1 * week_matrix / theta_matrix
        term_3 = jnp.log(theta_matrix) * k_matrix
        term_4 = jax.scipy.special.gammaln(k_matrix)
        gamma_pdf_log = term_0 + term_1 + term_2 - (term_3 + term_4)
        return jnp.exp(gamma_pdf_log)

    def _ad_effect(self, ad_spend_tensor, beta, kappa, dims):
        beta_matrix = jnp.tile(beta, (1, dims.weeks, dims.days, 1, 1))
        kappa_matrix = jnp.tile(kappa, (1, dims.weeks, dims.days, 1, 1))
        s_matrix = 0.5 * jnp.ones_like(kappa_matrix)
        Z = ad_spend_tensor.reshape(
            (dims.tracks, dims.weeks, dims.days, 1, dims.channels)
        )
        Z = jnp.tile(Z, (1, 1, 1, dims.dsps, 1))
        term1 = beta_matrix
        term2 = jnp.power(kappa_matrix, s_matrix)
        term3 = jnp.power(Z, s_matrix) + term2
        ad_effect = (term1) * (1 - term2 / term3)
        return ad_effect


# COMMAND ----------
