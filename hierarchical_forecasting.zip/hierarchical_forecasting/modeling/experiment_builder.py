import logging
import mlflow
import numpy as np
from hierarchical_forecasting.modeling.hierarchical_forecast_model import (
    HierarchicalForecastModel,
)
from hierarchical_forecasting.modeling.inference_model import InferenceModel
from hierarchical_forecasting.modeling.inference_model_wrapper import (
    InferenceModelWrapper,
)

def init_model(n_warmup, n_samples, discount):
    hfm = HierarchicalForecastModel(discount)

    logging.debug("Running...")

    model_wrapper = InferenceModelWrapper(
        InferenceModel(
            hfm,
            num_samples=n_samples,
            num_warmup=n_warmup,
            num_chains=1,
            chain_method="parallel",
            progress_bar=True,
        )
    )
    return model_wrapper


def fit_model(model_wrapper, X, y, tags, data_processing_instance):
    """Instantiate and fit hierarchical forecast model.

    Args:
        model_wrapper (InferenceModelWrapper):
        X (np.ndarray): Model features.
        y (np.array): Model target variable.
        tags (dict): dictionary of hierarchical model info
        data_processing_instance (DataProcessing):

    Returns:
        InferenceModelWrapper: Fitted hierarchical model.
    """
    model_wrapper.fit(X, y, tags, data_processing_instance)

    return model_wrapper


def execute_ad_spend_allocation_optimization(
    model_wrapper,
    posterior_samples,
    X,
    budget,
    data_processing_instance
):
    """Execute optimization for resource allocation over days and dsps.

    Args:
        model_wrapper (InferenceModelWrapper):
        posterior_samples (dict):
        X (np.ndarray):
        request (dict):
        data_processing_instance (DataProcessing):

    Returns:
        np.array: Optimal resource allocation results.
    """
    ad_spend_flag = data_processing_instance.ad_spend_flag
    any_budget = sum(budget) > 1.0
    if ad_spend_flag and any_budget:
        opt_alloc, opt_alloc_matrix = model_wrapper.optimization_wrapper(
            budget, posterior_samples
        )
    else:
        opt_alloc = np.zeros_like(X)
        opt_alloc_matrix = np.zeros((len(budget), 7, X.shape[-1]))

    return opt_alloc, opt_alloc_matrix

def mlflow_log_encoder(encoder):
    """Build the list of labels in a label encoder.
    Args:
        encoder (MyLabelEncoder):
    Returns:
        list: strs of labels for logging.
    """

    return encoder.classes_.tolist()

def mlflow_log_tags_dict(tags):
    """Build the log dictionary of hierarchical model info in tags.
    Args:
        tags (dict): dictionary of hierarchical model info
    Returns:
        dict: Hierarchical model info for logging.
    """
    log_tags = {}
    for k, v in tags.items():
        try:
            log_tags[k] = v.tolist()
        except:
            log_tags[k] = v
    return log_tags