import cvxpy as cp
from cvxpy.atoms.elementwise.inv_pos import inv_pos
from cvxpy.atoms.elementwise.power import power as cp_power
import numpy as np

class AdSpendOptimization():
    def __init__(self):
        pass

    @staticmethod
    def optimal_allocation(m, beta, kappa, budget):
        # takes median of posterior samples -> return optimal allocation in shape (horizon, n_days =7, n_channels)
        b = np.array(budget)
        beta = np.array(beta, dtype='float64')
        kappa = np.array(kappa, dtype='float64')
        m = np.array(m, dtype='float64')
        print('beta',beta.tolist())
        print('kappa',kappa.tolist())
        print('m', m.tolist())
        n_dsps, n_channels = beta.shape
        days = 7
        horizon = b.shape[0]
        x = {}
        for ch in range(n_channels):
            x[ch] = cp.Variable((horizon, days))
        impact = 0
        constr = []
        total_spend = np.zeros(horizon)
        for dsp in range(n_dsps):
            for ch in range(n_channels):
                term1 = cp_power(x[ch], 0.5)
                term2 = kappa[dsp, ch] ** 0.5
                C = (beta[dsp, ch] * (1 - term2 * inv_pos(term2 + term1)))
                A = C  * m[:, dsp]
                impact += cp.sum(A)

        for ch in range(n_channels):
            constr += [x[ch] >= 0]
            total_spend += cp.sum(x[ch], axis=1)
        constr += [total_spend <= b]

        # sums problem objectives and concatenates constraints.
        problem = cp.Problem(cp.Maximize(impact), constr)
        solvers =  {'ECOS':cp.ECOS, 'ECOS_BB':cp.ECOS_BB, 'OSQP':cp.OSQP, 'SCIPY':cp.SCIPY, 'SCS':cp.SCS}
        n_solvers = len(list(solvers.keys()))
        for solver, cp_solver in solvers.items():
            try:
                print(f"trying to optimize with {solver}...")
                problem.solve(solver=cp_solver,verbose=True)
                res = np.stack([x[ch].value for ch in range(n_channels)], axis=-1)
                res = np.maximum(res, np.zeros_like(res))
                return res
            except cp.SolverError as e:
                print(f"{solver} failed, trying next solver...")
        return None

