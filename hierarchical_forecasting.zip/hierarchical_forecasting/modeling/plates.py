import numpyro
import hierarchical_forecasting.modeling.dimensions
class Plates:
    def __init__(self, dims):
        self.artists = numpyro.plate("artists", dims.artists, dim=-5)
        self.tracks = numpyro.plate("tracks", dims.tracks, dim=-5)
        self.channels = numpyro.plate("channels", dims.channels, dim=-1)
        self.dsps = numpyro.plate("dsps", dims.dsps, dim=-2)
        self.weeks = numpyro.plate("weeks", dims.weeks, dim=-4)
        self.days = numpyro.plate("days", dims.days, dim=-3)

