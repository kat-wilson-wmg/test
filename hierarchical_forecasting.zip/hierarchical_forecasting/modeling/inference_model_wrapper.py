import mlflow.pyfunc
import numpy as np
import sys


class InferenceModelWrapper(mlflow.pyfunc.PythonModel):
    def __init__(self,model):
        self.model = model

    def fit(self,X_train,y_train,tags,data_processing_instance):
        self.model.fit(X_train,y_train,tags,data_processing_instance)

    def load_context(self, context):
        sys.path += [context.artifacts["code_path"]]

    def optimization_wrapper(self,X,posterior_samples):
        return self.model.optimization_wrapper(X,posterior_samples)

    def posterior_predictive(self, X):
        return self.model.posterior_predictive(X)

    def predict(self, X):
        return self.model.predict(X)

    def get_conda_env(self):
        return  {
        "channels": ["defaults"],
        "dependencies": [
            "python=3.8.8",
            "pip",
            {
                "pip": [
                    "mlflow",
                    "arviz",
                    "cvxpy",
                    "pandas==1.1.3",
                    "numpy==1.19.2",
                    "numpyro==0.6.0",
                    "jax==0.2.10",
                    "cloudpickle==1.6.0",
                ]
            },
        ],
        "name": "hierarchical_forecasting",
    }

    def get_pred_input(self,X,tags,denom):
        return  {
        "X": X,
        "tags": tags,
        "denom": denom,
        "samples": self.model.samples,
    }




