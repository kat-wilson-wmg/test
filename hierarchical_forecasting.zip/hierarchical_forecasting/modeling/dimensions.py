class Dimensions:
    def __init__(self, dims_dict):
        self.tracks = dims_dict["n_tracks"]
        self.artists = dims_dict["n_artists"]
        self.weeks = dims_dict["n_weeks"]
        self.days = dims_dict["n_days"]
        self.features = dims_dict["n_features"]
        self.channels = dims_dict["n_channels"]
        self.playlist_feats = dims_dict["n_pl_feats"]
        self.aural_feats = dims_dict["n_aural_feats"]
        self.dsps = dims_dict["n_dsps"]

    def tolist(self):
        return [
            self.tracks,
            self.artists,
            self.weeks,
            self.days,
            self.features,
            self.channels,
            self.playlist_feats,
            self.aural_feats,
            self.dsps,
        ]
