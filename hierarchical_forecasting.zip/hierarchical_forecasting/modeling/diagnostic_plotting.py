import arviz as az
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns

from matplotlib import ticker


def trace_plots(arviz_data, var_names):
    """Formats x when x represent time since release.

    Args:
        x (float): x-tick-label
        pos : position of x-tick todo: add type

    Returns:
        str: of tick label
    """
    az.plot_trace(arviz_data, compact=True, var_names=var_names)
    plt.show()


def _plot_historical_for_track_dsp(ax, y_train, y_test, denom, track_idx, dsp_idx, n_ticks):
    color_dict = _colors()
    hist_color = color_dict['hist'][dsp_idx]
    y_data = {'train': {}, 'test': {}}
    y_data['train']['data'] = y_train[track_idx, :, :, dsp_idx].reshape(n_ticks)
    y_data['train']['idx'] = np.where(~np.isnan(y_data['train']['data']))
    y_data['test']['data'] = y_test[track_idx, :, :, dsp_idx].reshape(n_ticks)
    y_data['test']['idx'] = np.where(~np.isnan(y_data['test']['data']))
    for str_ in ['train', 'test']:
        idx = y_data[str_]['idx']
        data = y_data[str_]['data']
        ax.scatter(
            idx,
            data[idx] * denom,
            label=f"{str_} data",
            color=hist_color,
            marker=".",
            s=5,
        )

def _plot_prediction_for_track_dsp(ax, y_pred_samples, track_idx, dsp_idx, n_ticks):
    color_dict = _colors()
    n_samples = y_pred_samples[0]
    pred_color = color_dict['pred'][dsp_idx]
    track_y_pred_samples = y_pred_samples[:, track_idx, :, :, dsp_idx].reshape(
        (n_samples, n_ticks)
    )
    ax.plot(np.median(track_y_pred_samples, axis=0), label="predictions", color=pred_color)
    for q, alpha in zip([0.25, 0.45], [0.1, 0.25]):
        top = np.quantile(track_y_pred_samples, q=0.5 + q, axis=0)
        btm = np.quantile(track_y_pred_samples, q=0.5 - q, axis=0)
        q_str = int(q * 2)
        ax.fill_between(
            np.arange(n_ticks),
            btm,
            top,
            alpha=alpha,
            label=f"{q_str} CI",
            color=pred_color,
        )
def prediction_plot(
    y_train, y_test, track_le, dsp_le , denom, y_pred_samples
):
    n_samples, n_tracks, n_weeks, _, n_dsps = y_pred_samples.shape
    n_ticks = n_weeks * 7
    for track_idx in range(n_tracks):
        fig, axs = plt.subplots(n_dsps, 1, figsize=(12, 2 * n_dsps), sharex=True)
        for dsp_idx in range(n_dsps):
            ax = axs[dsp_idx] if n_dsps > 1 else ax
            _plot_prediction_for_track_dsp(ax, y_train, y_test, denom, track_idx, dsp_idx, n_ticks)
            _plot_historical_for_track_dsp(ax, y_pred_samples, track_idx, dsp_idx, n_ticks)
            dsp_ = dsp_le.inverse_transform([dsp_idx])[0]
            dsp_name = dsp_.split("_")[-1]
            title = track_le.inverse_transform([track_idx])
            str_title = f'{title[0]}  {dsp_name}'
            ax.set_title(str_title)
        plt.legend()
        plt.show()


def _colors():
    colors = list(sns.color_palette("Paired"))
    pred_colors = [color for i, color in enumerate(colors) if i % 2 == 0]
    hist_colors = [color for i, color in enumerate(colors) if i % 2 == 1]
    return {'pred':pred_colors,'hist':hist_colors}