from hierarchical_forecasting.post_processing.plotting import (
    time_series_plot_data_builder,
)
from hierarchical_forecasting.post_processing.plotting import (
    time_series_plot_figure_builder,
)


def build(y_train, y_test, data_processing_instance, y_pred_samples, time_horizon=30):
    """Builds the prediction time series plot with historical and forecast data.

    Args:
        y_train (np.ndarray): Train dataset of streams.
        y_test (np.ndarray): Test dataset of streams.
        data_processing_instance (DataProcessing):
        y_pred_samples (np.ndarray): Poster sample results for predicted streams.
        time_horizon (int): Prediction time horizon.

    Returns
        matplotlib.pyplot.figure: Plot of time series prediction data by dsp.
    """
    plot_params_dict = _plot_params_dict(y_pred_samples, data_processing_instance, time_horizon)

    plot_data_by_dsp_dict = time_series_plot_data_builder.build(
        y_train, y_test, y_pred_samples, plot_params_dict
    )

    fig, ax = time_series_plot_figure_builder.build(
        plot_data_by_dsp_dict, plot_params_dict
    )

    return fig, ax


def _plot_params_dict(y_pred_samples, data_processing_instance, time_horizon):
    """Build dictionary of parameters to be used across plotting functions.

    Args:
        y_pred_samples (np.ndarray):
        data_processing_instance (DataProcessing):
        time_horizon (int):

    Returns
        dict: Contains parameters for the prediction sample.
    """
    n_samples, n_tracks, n_weeks, _, n_dsps = y_pred_samples.shape
    n_ticks = n_weeks * 7
    track_idx = n_tracks - 1

    dsp_names_list = _get_dsp_names(data_processing_instance, n_dsps)

    plot_params_dict = {
        "n_samples": n_samples,
        "n_tracks": n_tracks,
        "n_weeks": n_weeks,
        "n_dsps": n_dsps,
        "n_ticks": n_ticks,
        "track_idx": track_idx,
        "denom": data_processing_instance.denom,
        "time_horizon": time_horizon,
        "dsp_names_list": dsp_names_list,
        "release_dates": data_processing_instance.request_release_dates
    }

    return plot_params_dict

def _get_dsp_names(data_processing_instance, n_dsps):
    dsp_le = data_processing_instance.features_le
    dsp_names_list = dsp_le.classes_[:n_dsps]
    dsp_actual_names = [dsp_name.split('_')[-1] for dsp_name in dsp_names_list]
    return dsp_actual_names