def plot_saturation_curves(self, beta, kappa, le_dict):
    dsp_le = le_dict["features"]
    beta = np.power(beta, 2.0)
    kappa = np.power(kappa, 2.0)
    colors = list(sns.color_palette("Paired"))
    n_samples = kappa.shape[0]
    n_dsps, n_channels = kappa.shape[-2:]
    max_spend = 100
    beta = np.tile(beta, (1, 1, max_spend, 1, 1, 1))
    kappa = np.tile(kappa, (1, 1, max_spend, 1, 1, 1))
    s = 0.5 * np.ones_like(kappa)
    Z = np.linspace(0, max_spend, num=max_spend).reshape((1, 1, max_spend, 1, 1, 1))
    Z = np.tile(Z, (n_samples, 1, 1, 1, n_dsps, n_channels))
    term2 = np.power(kappa, s)
    term3 = np.power(Z, s) + term2
    ad_effect = beta * (1 - term2 / term3)
    fig, axs = plt.subplots(
        n_dsps, n_channels, figsize=(3 * n_channels, 5 * n_dsps), sharey=True
    )
    for dsp in range(n_dsps):
        dsp_name = dsp_le.inverse_transform([dsp + n_channels])[0].split("_")[-1]
        for channel in range(n_channels):
            if n_channels == 1 and n_dsps == 1:
                ax = axs
            elif n_channels == 1 or n_dsps == 1:
                ax = axs[max(dsp, channel)]
            else:
                ax = axs[dsp, channel]
            chn_name = dsp_le.inverse_transform([channel])[0].split("_")[-1]
            channel_saturation_curve = ad_effect[:, :, :, :, dsp, channel].reshape(
                (n_samples, max_spend)
            )
            median_ch = np.quantile(channel_saturation_curve, q=0.5, axis=0)
            alphas = [0.2, 0.1]
            color = colors[2 * channel + 1]
            ax.plot(
                np.linspace(0, max_spend, num=max_spend),
                median_ch,
                label=chn_name,
                color=color,
            )
            for i, q in enumerate([0.25, 0.45]):
                btm = np.quantile(channel_saturation_curve, q=0.5 - q, axis=0)
                top = np.quantile(channel_saturation_curve, q=0.5 + q, axis=0)
                ax.fill_between(
                    np.linspace(0, max_spend, num=max_spend),
                    btm,
                    top,
                    alpha=alphas[i],
                    color=color,
                )
            ax.set_xlabel("$ spent")
            ax.set_ylabel("Carryover impact (multiplicative)")
            ax.legend(bbox_to_anchor=(1, 0.85))
    plt.show()
    return fig


def plot_ad_spend(
    self, X, y, le_dict, denom, ad_impact, track_indx, main_artist, plot_title=""
):
    track_le = le_dict["track"]
    dsp_le = le_dict["features"]
    colors = list(sns.color_palette("Paired"))
    bar_colors = [color for i, color in enumerate(colors) if i % 2 == 0]
    hist_colors = [color for i, color in enumerate(colors) if i % 2 == 1]
    ad_data = ad_impact[:, track_indx, :, :, :, :]
    n_samples, n_weeks, n_days, n_dsps, n_channels = ad_data.shape
    fig, axes = plt.subplots(n_dsps, 1, figsize=(12, 2 * n_dsps), sharex=True)
    for dsp in range(n_dsps):
        ax = axes
        if n_dsps > 1:
            ax = axes[dsp]
        dsp_ = dsp_le.inverse_transform([dsp + n_channels])[0]
        dsp_name = dsp_.split("_")[-1]
        title = track_le.inverse_transform([track_indx])[0]
        ax.set_title(dsp_name)
        second_y = ax.twinx()
        features = np.sum(np.nan_to_num(X[track_indx, :, :, :]), axis=-1).reshape(
            (n_weeks * n_days)
        )
        features_indx = np.where(features > 0)
        X_data = X[track_indx, :, :, 0].reshape((n_weeks * n_days))
        X_data = X_data[features_indx]
        bottom = np.zeros_like(X_data)
        markers = ["^", "8", "s", "p", "P", "*"]
        for ch in range(n_channels):
            X_data = X[track_indx, :, :, ch].reshape((n_weeks * n_days))
            X_data = X_data[features_indx]
            chn_name = dsp_le.inverse_transform([ch])[0]
            chn_name = chn_name.split("_")[-1]
            if features_indx is not None and X_data is not None:
                second_y.bar(
                    features_indx[0],
                    bottom=bottom,
                    height=X_data,
                    width=0.35,
                    alpha=0.7,
                    label=chn_name,
                    color=bar_colors[ch],
                )
                ad_effect = np.median(ad_data[:, :, :, dsp, ch], axis=0).reshape(
                    (n_weeks * n_days)
                )
                ax.plot(
                    features_indx[0],
                    ad_effect[features_indx] * denom,
                    marker=markers[ch],
                    label=chn_name,
                    color=hist_colors[ch],
                )
            bottom += X_data
            second_y.set_ylabel("$ spent")
            ax.set_ylabel("median carry over")

            def _day_x_formatter(x, pos):
                w = x // 7
                d = x % 7
                day = le_dict["days"].inverse_transform([int(d)])[0]
                day_dict = {
                    "Friday": "Fri",
                    "Saturday": "Sat",
                    "Sunday": "Sun",
                    "Monday": "Mon",
                    "Tuesday": "Tue",
                    "Wednesday": "Wed",
                    "Thursday": "Thu",
                }
                return f"wk{w:.0f}-{day_dict[day]}"

            for label in ax.xaxis.get_ticklabels(which="both"):
                label.set_visible(True)
            x_fmtr = ticker.FuncFormatter(_day_x_formatter)
            ax.get_xaxis().set_major_formatter(x_fmtr)
            for tick in second_y.get_xticklabels():
                tick.set_rotation(90)
    ax = axes
    if n_dsps > 1:
        ax = axes[-1]
    ax.legend(bbox_to_anchor=(0.5, -0.2), fancybox=True, shadow=True, ncol=n_channels)
    if title == "TOP TOP":
        title = main_artist + " New Release"
    fig.suptitle(plot_title + " for " + str(title))
    fig.tight_layout()
    # fig.subplots_adjust(bottom=0.2)
    plt.show()
    return fig


def plot_ad_spend_with_streams(
    self, X, y, le_dict, denom, ad_impact, y_pred_samples, track_indx, main_artist
):
    track_le = le_dict["track"]
    dsp_le = le_dict["features"]
    colors = list(sns.color_palette("Paired"))
    bar_colors = [color for i, color in enumerate(colors) if i % 2 == 0]
    hist_colors = [color for i, color in enumerate(colors) if i % 2 == 1]
    ad_data = ad_impact[:, track_indx, :, :, :, :]
    streams = y_pred_samples[:, track_indx, :, :, :]
    n_samples, n_weeks, n_days, n_dsps, n_channels = ad_data.shape
    fig, axes = plt.subplots(n_dsps, 1, figsize=(12, 2 * n_dsps), sharex=True)
    for dsp in range(n_dsps):
        ax = axes
        if n_dsps > 1:
            ax = axes[dsp]
        dsp_ = dsp_le.inverse_transform([dsp + n_channels])[0]
        dsp_name = dsp_.split("_")[-1]
        title = track_le.inverse_transform([track_indx])[0]
        ax.set_title(dsp_name)
        second_y = ax.twinx()
        features = np.sum(np.nan_to_num(X[track_indx, :, :, :]), axis=-1).reshape(
            (n_weeks * n_days)
        )
        features_indx = np.where(features > 0)
        X_data = X[track_indx, :, :, 0].reshape((n_weeks * n_days))
        X_data = X_data[features_indx]
        bottom = np.zeros_like(X_data)
        markers = ["^", "8", "s", "p", "P", "*"]
        track_streams = (
            np.median(streams[:, :, :, dsp], axis=0).reshape((n_weeks * n_days)) * denom
        )
        track_streams = track_streams[features_indx]
        stream_btm = track_streams
        ax.plot(
            features_indx[0],
            stream_btm,
            marker=markers[-1],
            label="before ad",
            color="black",
        )
        for ch in range(n_channels):
            X_data = X[track_indx, :, :, ch].reshape((n_weeks * n_days))
            X_data = X_data[features_indx]
            chn_name = dsp_le.inverse_transform([ch])[0]
            chn_name = chn_name.split("_")[-1]
            if features_indx is not None and X_data is not None:
                second_y.bar(
                    features_indx[0],
                    bottom=bottom,
                    height=X_data,
                    width=0.35,
                    alpha=0.7,
                    label=chn_name,
                    color=bar_colors[ch],
                )
                ad_effect = np.median(ad_data[:, :, :, dsp, ch], axis=0).reshape(
                    (n_weeks * n_days)
                )
                ax.plot(
                    features_indx[0],
                    stream_btm + (ad_effect[features_indx]) * denom,
                    marker=markers[ch],
                    label=chn_name,
                    color=hist_colors[ch],
                )
                stream_btm += (ad_effect[features_indx]) * denom
            bottom += X_data
            second_y.set_ylabel("$ spent")
            ax.set_ylabel("stream count")

            def _day_x_formatter(x, pos):
                w = x // 7
                d = x % 7
                day = le_dict["days"].inverse_transform([int(d)])[0]
                day_dict = {
                    "Friday": "Fri",
                    "Saturday": "Sat",
                    "Sunday": "Sun",
                    "Monday": "Mon",
                    "Tuesday": "Tue",
                    "Wednesday": "Wed",
                    "Thursday": "Thu",
                }
                return f"wk{w:.0f}-{day_dict[day]}"

            for label in ax.xaxis.get_ticklabels(which="both"):
                label.set_visible(True)
            x_fmtr = ticker.FuncFormatter(_day_x_formatter)
            ax.get_xaxis().set_major_formatter(x_fmtr)
            for tick in second_y.get_xticklabels():
                tick.set_rotation(90)
    ax = axes
    if n_dsps > 1:
        ax = axes[-1]
    ax.legend(
        bbox_to_anchor=(0.5, -0.2), fancybox=True, shadow=True, ncol=n_channels + 1
    )
    if title == "TOP TOP":
        title = main_artist + " New Release"
    fig.suptitle(title)
    plt.show()
    return fig


def plot_ad_spend_allocation(self, opt_alloc, le_dict, plot_title=""):
    dsp_le = le_dict["features"]
    colors = list(sns.color_palette("Paired"))
    bar_colors = [color for i, color in enumerate(colors) if i % 2 == 0]
    fig = plt.figure(constrained_layout=False, figsize=(14, 5), facecolor="w")
    gs1 = fig.add_gridspec(nrows=2, ncols=14, wspace=0.154)
    ax1 = fig.add_subplot(gs1[:, 4:])
    ax2 = fig.add_subplot(gs1[0, :3])
    ax3 = fig.add_subplot(gs1[1, :3])
    n_weeks, n_days, n_channels = opt_alloc.shape
    opt_alloc_daily = opt_alloc.reshape((n_weeks * n_days, n_channels))
    bottom = np.zeros(n_weeks * n_days)
    ax = ax1
    for ch in range(n_channels):
        chn_name = dsp_le.inverse_transform([ch])[0]
        chn_name = chn_name.split("_")[-1]
        height = opt_alloc_daily[:, ch]
        ax.bar(
            np.arange(0, n_weeks * n_days),
            bottom=bottom,
            height=height,
            width=0.9,
            color=bar_colors[ch],
            label=chn_name,
        )
        # for i in range(n_weeks*n_days):
        #     ax.text(x=i, y=bottom[i] + height[i] / 2 , s =f'{round(opt_alloc_daily[i,ch])}',
        #             va='center',ha='center',fontsize= 10 + 5/n_weeks )
        bottom += height
    ax.legend(loc="upper left", bbox_to_anchor=(1.02, 1))
    ax.set_xlim(-0.45, n_weeks * n_days - 0.55)

    ax.set_ylabel("Budget Allocated to Channel (USD)")

    def _day_x_formatter(x, pos):
        w = x // 7
        d = x % 7
        day = le_dict["days"].inverse_transform([int(d)])[0]
        day_dict = {
            "Friday": "Fri",
            "Saturday": "Sat",
            "Sunday": "Sun",
            "Monday": "Mon",
            "Tuesday": "Tue",
            "Wednesday": "Wed",
            "Thursday": "Thu",
        }
        return f"wk{w:.0f}-{day_dict[day]}"

    ax.set_xticks(range(n_weeks * n_days))
    skip_tick = int(n_weeks * n_days // 14)
    if skip_tick > 1:
        for i, label in enumerate(ax.xaxis.get_ticklabels(which="both")):
            if i % skip_tick != 0:
                label.set_visible(False)
    x_fmtr = ticker.FuncFormatter(_day_x_formatter)
    ax.get_xaxis().set_major_formatter(x_fmtr)
    ax.grid(axis="y")
    for tick in ax.get_xticklabels():
        tick.set_rotation(90)
    ax = ax2
    channels_alloc = np.sum(opt_alloc_daily, axis=0)
    labels = dsp_le.inverse_transform(np.arange(n_channels))
    labels = [label.split("_")[-1] for label in labels]
    ax.pie(channels_alloc, labels=labels, autopct="%1.1f%%")

    ax = ax3
    days_alloc = np.sum(opt_alloc, axis=0)
    days_alloc = np.sum(days_alloc, axis=-1)
    labels = le_dict["days"].inverse_transform(np.arange(n_days))
    ax.pie(days_alloc, labels=labels, autopct="%1.1f%%")
    plt.suptitle(plot_title)
    fig.tight_layout()
    plt.show()

    return fig
