import matplotlib.pyplot as plt
import numpy as np
from hierarchical_forecasting.utils.colors import sns_paired_pallete_colors


def build(plot_data_by_dsp_dict, plot_params_dict):
    """Build time series figures.

    Args:
        plot_data_by_dsp_dict (dict):
        plot_params_dict (dict):

    Returns:
        matplotlib.figure: Plot of time series prediction data by dsp.
    """
    fig, ax = _initialize_fig_subplots(plot_params_dict)
    ax = _add_subplots_by_dsp(ax, plot_data_by_dsp_dict, plot_params_dict)

    fig.tight_layout()
    fig.show()

    return fig, ax


def _initialize_fig_subplots(plot_params_dict):
    """Initialize figure/axes with  number of subplots equal to number of request dsps.

    Args:
        plot_params_dict (dict):

    Returns:
        matplotlib.figure, matplotlib.axes:
    """
    fig, ax = plt.subplots(
        plot_params_dict["n_dsps"],
        1,
        figsize=(12, 4 * plot_params_dict["n_dsps"]),
        sharex=False,
    )

    return fig, ax


def _add_subplots_by_dsp(ax, plot_data_by_dsp_dict, plot_params_dict):
    """Add subplots to figure for each dsp.

    Args:
        fig (matplotlib.figure):
        ax (matplotlib.axes):
        plot_data_by_dsp_dict (dict):
        plot_params_dict (dict):

    Returns:
        np.ndarray:
    """
    colors_list = sns_paired_pallete_colors()
    for dsp_idx, dsp_name_str in enumerate(plot_params_dict["dsp_names_list"]):
        ax_dsp = ax[dsp_idx] if plot_params_dict["n_dsps"] > 1 else ax
        plot_color = colors_list[dsp_idx]
        ax_dsp = _add_subplot_for_dsp(
            ax_dsp,
            dsp_name_str,
            plot_color,
            plot_data_by_dsp_dict,
        )
        legend_title = dsp_name_str.split("_")[-1]
        ax_dsp.legend(
            title=legend_title,
            loc="upper left",
            bbox_to_anchor=(1.02, 1),
        )
    return ax


def _add_subplot_for_dsp(
    ax_dsp,
    dsp_name_str,
    plot_color,
    plot_data_by_dsp_dict,
):
    """Add subplot for a single dsp.

    Args:
        ax_dsp (matplotlib.axes._subplots.AxesSubplot):
        dsp_name_str (str):
        plot_color (str):
        plot_params_dict (dict):

    Returns:
        matplotlib.axes._subplots.AxesSubplot:
    """
    ax_dsp = _plot_historical_time_series(ax_dsp, dsp_name_str, plot_data_by_dsp_dict)

    x_plot_data_future = plot_data_by_dsp_dict[dsp_name_str]["future_predicted_data"][
        "x_plot"
    ]
    y_plot_data = plot_data_by_dsp_dict[dsp_name_str]["future_predicted_data"]["y_plot"]
    is_future = True
    ax_dsp = _plot_prediction_time_series(
        ax_dsp, x_plot_data_future, y_plot_data, is_future, plot_color
    )

    x_plot_data_past = plot_data_by_dsp_dict[dsp_name_str]["historical_predicted_data"][
        "x_plot"
    ]
    if x_plot_data_past.shape[0] > 0:
        y_plot_data = plot_data_by_dsp_dict[dsp_name_str]["historical_predicted_data"][
            "y_plot"
        ]
        is_future = False
        ax_dsp = _plot_prediction_time_series(
            ax_dsp,
            x_plot_data_past,
            y_plot_data,
            is_future,
            "grey",
        )
    ax_dsp.grid(axis="y", alpha=0.3)

    ax_dsp = _groom_xticks(ax_dsp, x_plot_data_past, x_plot_data_future)

    return ax_dsp


def _groom_xticks(ax_dsp, x_plot_data_past, x_plot_data_future):
    """Grooms the date labels in the x-axis lables

    Args:
        ax_dsp (matplotlib.axes._subplots.AxesSubplot):
        x_plot_data_past (np.array):
        x_plot_data_future (np.array):

    Returns:
        matplotlib.axes._subplots.AxesSubplot:
    """
    x_plot_data = np.concatenate((x_plot_data_past, x_plot_data_future), axis=0)
    skip_rate = len(x_plot_data) // 20 + 1
    ax_dsp.set_xticks(x_plot_data[::skip_rate])
    ax_dsp.set_xticklabels(x_plot_data[::skip_rate], rotation=20, ha="right")
    return ax_dsp


def _plot_historical_time_series(ax_dsp, dsp_name_str, plot_data_by_dsp_dict):
    """Plot historical time series.

    Args:
        ax_dsp (matplotlib.axes._subplots.AxesSubplot):
        dsp_name_str (str):
        plot_data_by_dsp_dict (dict):

    Returns:
        matplotlib.axes._subplots.AxesSubplot:
    """
    dataset_labels = ["train", "test"]
    markers = ["x", "^"]
    for dataset_label, marker in zip(dataset_labels, markers):
        x_data = plot_data_by_dsp_dict[dsp_name_str]["historical_data"][dataset_label][
            "x_plot"
        ]
        y_data = plot_data_by_dsp_dict[dsp_name_str]["historical_data"][dataset_label][
            "y_plot"
        ]
        if len(x_data) > 0:
            ax_dsp.scatter(
                x_data,
                y_data,
                label=f"{dataset_label} data",
                color="black",
                alpha=0.6,
                marker=marker,
                s=8,
            )

    return ax_dsp


def _plot_prediction_time_series(
    ax_dsp, x_plot_data, y_plot_data, is_future, plot_color
):
    """Plot prediction time series data for a given track and dsp.

    Args:
        ax_dsp (matplotlib.axes._subplots.AxesSubplot):
        x_plot_data (np.ndarray):
        y_plot_data (np.ndarray):
        is_future (bool):
        plot_color (str):

    Returns:
        matplotlib.axes._subplots.AxesSubplot:
    """
    label = "median predictions" if is_future else None
    ax_dsp.plot(x_plot_data, y_plot_data[50], label=label, alpha=0.6, color=plot_color)
    quantiles_list = [
        25,
        45,
    ]
    alphas_list = [0.1, 0.2]
    for q, alpha in zip(quantiles_list, alphas_list):
        q_str = int(2 * q)
        label = f"{q_str} CI" if is_future else None
        btm = y_plot_data[int(50 - q)]
        top = y_plot_data[int(50 + q)]
        ax_dsp.fill_between(
            x_plot_data,
            btm,
            top,
            alpha=alpha,
            label=label,
            color=plot_color,
        )

    return ax_dsp
