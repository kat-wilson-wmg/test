import datetime
import numpy as np


def build(y_train, y_test, y_pred_samples, plot_params_dict):
    """Prepare data for prediction plots for a multiple dsps.

    Args:
        y_train (np.ndarray):
        y_test  (np.ndarray):
        y_pred_samples (np.ndarray): Poster sample results for predicted streams.
        plot_params_dict (dict):

    Returns:
        dict: Contains all data for prediction plots.
    """
    plot_data_by_dsp_dict = {}
    for dsp_idx, dsp_name_str in enumerate(plot_params_dict["dsp_names_list"]):
        plot_data_by_dsp_dict[dsp_name_str] = _build_for_dsp(
            y_train, y_test, y_pred_samples, dsp_idx, dsp_name_str, plot_params_dict
        )

    return plot_data_by_dsp_dict


def _build_for_dsp(
    y_train, y_test, y_pred_samples, dsp_idx, dsp_name_str, plot_params_dict
):
    """Prepare data for prediction plots for a single dsp.

    Args:
        y_train (np.ndarray):
        y_test  (np.ndarray):
        y_pred_samples (np.ndarray): Poster sample results for predicted streams.
        dsp_idx (int): Index for the dsp.
        plot_params_dict (dict):

    Returns:
        dict: Contains all data for prediction plots.
    """
    y_train_plot = y_train[plot_params_dict["track_idx"], :, :, dsp_idx].reshape(
        plot_params_dict["n_ticks"]
    )
    y_test_plot = y_test[plot_params_dict["track_idx"], :, :, dsp_idx].reshape(
        plot_params_dict["n_ticks"]
    )

    output_data_dict = {}

    output_data_dict["y_pred_samples"] = y_pred_samples
    release_date = plot_params_dict["release_dates"][dsp_name_str]

    output_data_dict["historical_data"] = _build_historical_data(
        y_train_plot, y_test_plot, plot_params_dict, release_date
    )

    output_data_dict = _build_prediction_data(
        output_data_dict,
        y_train_plot,
        y_test_plot,
        y_pred_samples,
        dsp_idx,
        release_date,
        plot_params_dict,
    )

    return output_data_dict


def _build_historical_data(y_train_plot, y_test_plot, plot_params_dict, release_date):
    """Build plotting dataset for actual historical data.

    Args:
        y_train_plot (np.ndarray):
        y_test_plot (np.ndarray):
        plot_params_dict (dict):
        release_date (datetime)

    Returns:
        dict: Contains actual historical data for plotting.
    """
    output_data_dict = {}

    output_data_dict["train"] = {}

    x_valid_idxs = np.where(~np.isnan(y_train_plot))[0]
    if x_valid_idxs.shape[0]:
        start_indx = x_valid_idxs[-1] - plot_params_dict["time_horizon"]
    else:
        start_indx = 0
    x_ticks = x_valid_idxs[np.where(x_valid_idxs > start_indx)]

    y_plot = y_train_plot[x_ticks] * plot_params_dict["denom"]

    output_data_dict["train"]["y_plot"] = y_plot
    output_data_dict["train"]["x_plot"] = (
        release_date + datetime.timedelta(days=1) * x_ticks
    )

    output_data_dict["test"] = {}
    x_ticks = np.where(~np.isnan(y_test_plot))[0]
    y_plot = y_test_plot[x_ticks] * plot_params_dict["denom"]
    output_data_dict["test"]["y_plot"] = y_plot
    output_data_dict["test"]["x_plot"] = (
        release_date + datetime.timedelta(days=1) * x_ticks
    )

    return output_data_dict


def _build_prediction_data(
    output_data_dict,
    y_train_plot,
    y_test_plot,
    y_pred_samples,
    dsp_idx,
    release_date,
    plot_params_dict,
):
    """Build predicted data for historical and future.

    Args:
        output_data_dict (dict):
        y_train_plot (np.ndarray):
        y_test_plot (np.ndarray):
        dsp_idx (ind):
        release_date (datetime):
        plot_params_dict (dict):

    Returns:
        dict: Contains historical and future model predicted data.
    """
    y_pred_samples_plot = y_pred_samples[
        :, plot_params_dict["track_idx"], :, :, dsp_idx
    ].reshape((plot_params_dict["n_samples"], plot_params_dict["n_ticks"]))
    y_pred_samples_plot = np.maximum(y_pred_samples_plot, 0)
    future_plot_start_idx = _future_plot_start_idx(y_train_plot, y_test_plot)

    output_data_dict["historical_predicted_data"] = _build_past_prediction_data(
        y_pred_samples_plot, future_plot_start_idx, release_date, plot_params_dict
    )
    output_data_dict["future_predicted_data"] = _build_future_prediction_data(
        y_pred_samples_plot,
        future_plot_start_idx,
        release_date,
        plot_params_dict,
    )

    return output_data_dict


def _build_past_prediction_data(
    y_pred_samples_plot, future_plot_start_idx, release_date, plot_params_dict
):
    """Build historical predicted data.

    Args:
        y_pred_samples_plot (np.ndarray):
        future_plot_start_idx (int):
        release_date (datetime):
        plot_params_dict (dict):

    Returns:
        dict: Contains historical model predicted data.
    """
    historical_predicted_data_dict = _build_predicted_data(
        future_plot_start_idx,
        y_pred_samples_plot,
    )
    start_indx = max(0, future_plot_start_idx - plot_params_dict["time_horizon"])
    end_indx = future_plot_start_idx
    x_ticks = np.arange(start_indx, end_indx)
    x_ticks_date_time = release_date + datetime.timedelta(days=1) * x_ticks
    historical_predicted_data_dict["x_plot"] = x_ticks_date_time

    for q in _quantiles_list():
        historical_predicted_data_dict["y_plot"][q] = historical_predicted_data_dict[
            "y_plot"
        ][q][x_ticks]

    return historical_predicted_data_dict


def _build_future_prediction_data(
    y_pred_samples_plot, future_plot_start_idx, release_date, plot_params_dict
):
    """Build future predicted data.

    Args:
        y_pred_samples_plot (np.ndarray):
        future_plot_start_idx (int):
        release_date (datetime):
        plot_params_dict (dict):

    Returns:
        dict: Contains future model predicted data.
    """
    future_predicted_data_dict = _build_predicted_data(
        future_plot_start_idx, y_pred_samples_plot
    )

    x_ticks = np.arange(
        future_plot_start_idx,
        future_plot_start_idx + plot_params_dict["time_horizon"],
    )
    x_ticks_datetime = release_date + datetime.timedelta(days=1) * x_ticks
    future_predicted_data_dict["x_plot"] = x_ticks_datetime
    for q in _quantiles_list():
        future_predicted_data_dict["y_plot"][q] = future_predicted_data_dict["y_plot"][
            q
        ][x_ticks]

    return future_predicted_data_dict


def _future_plot_start_idx(y_train_plot, y_test_plot):
    """Get index on which future plot timestamps start.

    Args:
        y_train_plot (np.ndarray):
        y_test_plot (np.ndarray):

    Returns:
        int: Start index for future plot timestamps.
    """
    x_valid_max_train = _valid_max_start_idx(y_train_plot)
    x_valid_max_test = _valid_max_start_idx(y_test_plot)
    start_idx = max(x_valid_max_train, x_valid_max_test)

    return start_idx


def _valid_max_start_idx(y_data):
    """Get valid start index on which to start future timestamps.

    Args:
        y_data (np.ndarray):

    Returns:
        int: Valid start index on which to start future timestamps.
    """
    x_data = np.where(~np.isnan(y_data))[0]
    x_valid_max = max(x_data) + 1 if len(x_data) > 0 else 0

    return x_valid_max


def _build_predicted_data(future_plot_start_idx, y_pred_samples):
    """Build plotting dataset for predicted historical data.

    Args:
        future_plot_start_idx (int):
        y_pred_samples (np.ndarray):

    Returns:
        dict: Contains predicted historical data for plotting.
    """
    output_data_dict = {"y_plot": {}}

    for q in _quantiles_list():
        output_data_dict["y_plot"][q] = np.quantile(y_pred_samples, q=q / 100.0, axis=0)

    x_plot_vals = output_data_dict["y_plot"][50]
    x_plot_vals = x_plot_vals.shape[0]
    x_plot_vals = np.arange(x_plot_vals)
    output_data_dict["x_plot"] = x_plot_vals

    return output_data_dict


def _quantiles_list():
    quantiles_list = [5, 25, 50, 75, 95]

    return quantiles_list
