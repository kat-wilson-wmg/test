import datetime
import matplotlib.pyplot as plt
import numpy as np
from hierarchical_forecasting.utils.colors import sns_paired_pallete_colors
from hierarchical_forecasting.utils.weekdays import weekdays


def build(allocations, data_processing_instance, any_budget):
    """Build allocation figures.

    Args:
        allocations (np.ndarray):
        data_processing_instance (DataProcessing):
        any_budget (bool)

    Returns:
        matplotlib.figure: Plots of add-spend allocations, None if no budget
    """

    if any_budget and data_processing_instance.ad_spend_flag:
        fig, ax_bars, ax_pie_1, ax_pie_2 = _initialize_fig_subplots()
        channel_names = _extract_channel_name(data_processing_instance)
        last_obs_date = data_processing_instance.last_observation_date
        _add_ad_alloc_bar_plot(ax_bars, allocations, channel_names, last_obs_date)
        _add_channels_pie_chart(ax_pie_1, allocations, channel_names)
        _add_days_pie_chart(ax_pie_2, allocations)
        fig.tight_layout()
        fig.show()
    else:
        fig = None
    return fig

def _extract_channel_name(data_processing_instance):
    """Extracts channel names from data_processing object.

    Args:
        data_processing_instance (DataProcessing):

    Returns:
        list of channel names
    """
    n_dsps = data_processing_instance.dims.dsps
    n_channels = data_processing_instance.dims.channels
    features_le = data_processing_instance.features_le
    channel_names = features_le.classes_[n_dsps : n_dsps + n_channels]
    return channel_names


def _initialize_fig_subplots():
    """Initialize figure/axes with pie charts for weekly and channel allocations
    and stacked bar chart for budget allocation

    Returns:
        matplotlib.figure, matplotlib.axes:
    """
    fig = plt.figure(constrained_layout=False, figsize=(16, 6), facecolor="w")
    gs = fig.add_gridspec(nrows=2, ncols=14, wspace=0.154)
    ax_bars = fig.add_subplot(gs[:, 7:])
    ax_pie_1 = fig.add_subplot(gs[0, :7])
    ax_pie_2 = fig.add_subplot(gs[1, :7])
    return fig, ax_bars, ax_pie_1, ax_pie_2


def _add_ad_alloc_bar_plot(ax_bars, allocations, channel_names, last_obs_date):
    """Add a stacked bar chart for allocation across different weeks.

    Args:
        fig (matplotlib.figure):
        ax (matplotlib.axes):
        allocations (np.ndarray):
        channel_names (channel_names):
        last_obs_date (datetime)

    Returns:
        matplotlib.axes:
    """
    n_weeks, n_days, n_channels = allocations.shape
    n_ticks = n_weeks * 7
    allocations_2d = allocations.reshape((n_ticks, n_channels))
    bar_colors = sns_paired_pallete_colors(dark=True)
    bottom = np.zeros(n_ticks)
    x_ticks = np.arange(0, n_weeks * n_days)
    x_ticks_dates = last_obs_date + datetime.timedelta(days=1) * x_ticks
    for i, chn_name in enumerate(channel_names):
        chn_name = chn_name.split("_")[-1]
        height = allocations_2d[:, i]
        ax_bars.bar(
            x_ticks,
            bottom=bottom,
            height=height,
            width=0.9,
            color=bar_colors[i],
            label=chn_name,
        )
        skip_rate = len(x_ticks) // 20 + 1
        ax_bars.set_xticks(x_ticks[::skip_rate])
        ax_bars.set_xticklabels(x_ticks_dates[::skip_rate], rotation=30, ha="right")
        bottom += height
    ax_bars.legend(loc="upper left", bbox_to_anchor=(1.02, 1))
    ax_bars.set_xlim(-0.45, n_ticks - 0.55)
    ax_bars.set_ylabel("Budget Allocated to Channel (USD)")
    ax_bars.set_title("Optimal Allocation of Your Budget",fontsize=15)
    ax_bars.grid(axis="y")
    return ax_bars


def _add_channels_pie_chart(ax_pie, allocations, channel_names):
    """Add a pie chart for allocation across different channels.

    Args:
        fig (matplotlib.figure):
        ax (matplotlib.axes):
        allocations (np.ndarray):
        channel_names (channel_names):

    Returns:
        matplotlib.axes:
    """
    channels_alloc = np.sum(allocations, axis=(0, 1))
    channels_alloc_normalized = _normalize_vector(channels_alloc)
    pie_labels = [channel_name.split("_")[-1] for channel_name in channel_names]
    explode = [.06 for _ in pie_labels]
    colors = sns_paired_pallete_colors(dark=True)[: len(pie_labels)]
    ax_pie.pie(
        channels_alloc_normalized,
        labels=pie_labels,
        autopct="%1.1f%%",
        colors=colors,
        explode=explode,
    )

    return ax_pie


def _add_days_pie_chart(ax_pie, allocations):
    """Add a pie chart for allocation across different channels.

    Args:
        fig (matplotlib.figure):
        ax (matplotlib.axes):
        allocations (np.ndarray):
    Returns:
        matplotlib.axes:
    """
    days = weekdays.weekdays()
    days_alloc = np.sum(allocations, axis=(0, 2))
    days_alloc_normalized = _normalize_vector(days_alloc)
    explode = [.06 for _ in days]
    ax_pie.pie(days_alloc_normalized, labels=days, autopct="%1.1f%%", explode=explode)
    return ax_pie


def _normalize_vector(vector):
    total = np.sum(vector)
    return vector / total
