import logging

from hierarchical_forecasting.utils.notification import Notification


def send(data_df, time_series_fig, ad_spend_fig, data_processing_instance, request):
    """Send result email.

    Args:
        data_df (pd.DataFrame):
        time_series_fig (matplotlib.Figure):
        ad_spend_fig (matplotlib.Figure):
        data_processing_instance (DataProcessing):
        request (dict):
    """
    notification = Notification()
    email_data_df = data_df.drop_duplicates(["PRODUCT_ARTIST_NAME"])[
        ["PRODUCT_ARTIST_NAME", "DSP"]
    ].reset_index(drop=True)
    ad_spend_flag = data_processing_instance.ad_spend_flag
    any_budget = sum(request["ADSPEND"]) > 1.0
    if ad_spend_flag and any_budget:
        figure_to_mail = ad_spend_fig
    else:
        figure_to_mail = None
    try:
        logging.warning(
            notification.send_email_pred(
                request["CLIENT_EMAIL"],
                request,
                email_data_df,
                time_series_fig,
                figure_to_mail,
            )
        )
    except Exception as e:
        logging.warning("Notification Failed")
        print(f"FAILED on:\n{request}")
        print(e)
