import numpy as np


def build_predection_result(pred_samples, dsp_display_name):
    """Makes a dictionary that summarizes predictions sample into p-tiles

    Args:
        pred_samples (np.ndarray):
        dsp_display_name (str):

    Returns:
        predictions summary dict
    """
    predictions = {}
    pred_samples_cumsum = np.cumsum(pred_samples, axis=-1)
    for q in [0, 0.25, 0.45]:
        predictions[f"new_streams_{round(50 + 100 * q)}"] = [
            round(num) for num in list(np.quantile(pred_samples, q=0.5 + q, axis=0))
        ]
        predictions[f"new_streams_{round(50 - 100 * q)}"] = [
            round(num) for num in list(np.quantile(pred_samples, q=0.5 - q, axis=0))
        ]
        predictions[f"cummulative_{round(50 + 100 * q)}"] = [
            round(num)
            for num in list(np.quantile(pred_samples_cumsum, q=0.5 + q, axis=0))
        ]
        predictions[f"cummulative_{round(50 - 100 * q)}"] = [
            round(num)
            for num in list(np.quantile(pred_samples_cumsum, q=0.5 - q, axis=0))
        ]
    return predictions


def build(y, data_processing_instance, y_pred_samples):
    """Makes a dictionary of results summary for the UI.

    Args:
        y (np.ndarray): observation data
        data_processing_instance (DataProcessing):
        y_pred_samples (np.ndarray): prediction samples

    Returns:
        result summary dict
    """

    historic_data = {}
    predictions = {}

    dims = data_processing_instance.dims
    n_samples = y_pred_samples.shape[0]
    n_ticks = dims.weeks * 7

    y_pred_samples_pos = np.maximum(y_pred_samples, 0)
    y_pred_samples_pos = np.nan_to_num(y_pred_samples_pos)

    dsps_indx = range(dims.dsps)
    features_le = data_processing_instance.features_le
    dsps_list = features_le.inverse_transform(dsps_indx)
    dsps_display_name = [name.split("_")[-1] for name in dsps_list]
    for dsp_id, dsp_name in enumerate(dsps_display_name):
        request_track_dsp = y[-1, : , : , dsp_id].reshape(n_ticks)
        x_dsp_data = np.where(~np.isnan(request_track_dsp))[0]
        y_dsp_data = request_track_dsp[x_dsp_data]
        denom = data_processing_instance.denom
        historic_data[dsp_name] = {
            "x": [int(num) for num in x_dsp_data],
            "y": [int(num * denom) for num in y_dsp_data],
        }
        pred_samples = y_pred_samples_pos[:, -1, :, :, dsp_id].reshape(
            (n_samples, n_ticks)
        )
        predictions[dsp_name] = build_predection_result(pred_samples, dsp_name)
        release_dates_dict = data_processing_instance.request_release_dates
        release_dates_str_dict = {k:str(v) for k,v in release_dates_dict.items()}
    inference_data_dict = {
        "artist_count": dims.artists,
        "tracks_count": dims.tracks,
        "release_dates":  release_dates_str_dict,
        "historic_data": historic_data,
        "prediction": predictions,
    }
    return inference_data_dict
