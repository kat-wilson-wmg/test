import json
import mlflow
import numpy as np

from collections import OrderedDict
from matplotlib import pyplot as plt

from hierarchical_forecasting.models.forecast.hierarchical_forecast_model import (
    HierarchicalForecastModel,
)
from hierarchical_forecasting.models.forecast.inference_model import InferenceModel
from hierarchical_forecasting.models.forecast.inference_model_wrapper import (
    InferenceModelWrapper,
)

# COMMAND ----------

# spam_spec = importlib.util.LazyLoader.load_module(fullname ='models')
# found = spam_spec is not None
# spam_spec.name == "eggs.spam"

# COMMAND ----------


class RunnerMLflow:
    def __init__(self, data_preprocessing, request):
        self.data_preprocessing = data_preprocessing
        self.request = request
        self.request_id = request["REQUEST_ID"]
        self.client_name = request["CLIENT_NAME"]
        self.client_email = request["CLIENT_EMAIL"]
        self.artist_name = request["ARTIST_NAME"]
        self.track_name = request["TRACK_NAME"]
        self.country_code = request["COUNTRY_CODE"]
        self.dsp = request["DSP"]
        self.horizon = request["HORIZON"]
        self.ad_spend_input = request["ADSPEND"]
        #self.inference_data_dict = self.data_preprocessing.build_inference_data_dict(
        #    data_preprocessing.train_test_data_dict["train_data_df"]
        #)



    def run_mlflow(self, num_samples=500, num_warmup=50, progress_bar=False):
        experiment_path = "/Production/PRODUCTION_s3_wmg-databricks"
        registered_model_name = "artist_track_level_hierarchical_forecasting_model"

        mlflow.set_experiment(experiment_path)
        with mlflow.start_run() as run:
            self.run_id = run.info.run_id
            print("running " + self.run_id)

            self.model_instance = InferenceModelWrapper(
                InferenceModel(
                    HierarchicalForecastModel(),
                    num_samples=num_samples,
                    num_warmup=num_warmup,
                    num_chains=1,
                    chain_method="parallel",
                    progress_bar=progress_bar,
                )
            )
            X_train = self.data_preprocessing.X_train
            y_train = self.data_preprocessing.y_train
            tags = self.data_preprocessing.tags
            self.model_instance.fit(X_train,y_train,tags)
            print('train_done')
            exit()
            try:
                track_sibling_msk = (
                    self.data_preprocessing.model_data_df["sibling_title"]
                    == self.model_instance.prediction_track_name
                )
                track_sibling_id = self.data_preprocessing.model_data_df.loc[
                    track_sibling_msk
                ]["sibling_id"].values[0]
                track_sibling_id = int(track_sibling_id)
            except:
                track_sibling_id = None

            pred_input = {
                "horizon": self.horizon,
                "artist_title": self.artist_name,
                "track_sibling_id": track_sibling_id,
                #'ad_spend': np.array(ad_spend_input.split(",")).astype(np.int),
            }

            self.predictions_dict = self.model_instance.predict(pred_input)
            self.model_level = self.model_instance.level

            related_artists_array = (
                self.data_preprocessing.train_test_data_dict["train_data_df"]
                .drop_duplicates(["sibling_title"])[["artist_name", "sibling_title"]]
                .values
            )
            self.related_artists_list = sorted(
                [" - ".join(list(pair)) for pair in related_artists_array]
            )

            if track_sibling_id is not None:
                prediction_track_code = self.model_instance.track_mapping_dict[
                    track_sibling_id
                ]
                prediction_indices = np.where(
                    np.array(self.inference_data_dict["obs_to_track_dict"])
                    == prediction_track_code
                )
                prediction_track_historic_weeks = list(
                    np.array(self.inference_data_dict["week"])[
                        prediction_indices
                    ].astype(int)
                )
                prediction_track_historic_streams = list(
                    np.array(self.inference_data_dict["stream"])[
                        prediction_indices
                    ].astype(int)
                )
                prediction_track_historic_streams = [
                    int(x) for x in prediction_track_historic_streams
                ]
                prediction_track_historic_weeks = [
                    int(x) for x in prediction_track_historic_weeks
                ]
                self.historic_data = {
                    "prediction_track_historic_weeks": prediction_track_historic_weeks,
                    "prediction_track_historic_streams": prediction_track_historic_streams,
                }
            else:
                self.historic_data = ""

            mlflow.log_dict(self.inference_data_dict, "inference_data_dict.json")
            log_predictions_dict = {
                k: v.tolist() for k, v in self.predictions_dict.items()
            }
            mlflow.log_dict(log_predictions_dict, "predictions.json")
            mlflow.log_figure(
                self.model_instance.graph_pred(
                    self.predictions_dict["predicted_streams"]
                ),
                "plot.png",
            )
            try:
                mlflow.log_figure(self.plot_predictions(), "plot_all.png")
            except:
                pass

            conda_env = {
                "channels": ["defaults"],
                "dependencies": [
                    "python=3.8.8",
                    "pip",
                    {
                        "pip": [
                            "mlflow",
                            "spotipy",
                            "pandas==1.1.3",
                            "numpy==1.19.2",
                            "numpyro==0.6.0",
                            "jax==0.2.10",
                            "cloudpickle==1.6.0",
                        ]
                    },
                ],
                "name": "hierarchical_forecasting_production",
            }

            # input_schema = mlflow.types.Schema([
            #   mlflow.types.ColSpec("string", "horizon"),
            #   mlflow.types.ColSpec("string", "ad_spend"),
            #   mlflow.types.ColSpec("string", "artist_indx"),
            #   mlflow.types.ColSpec("string", "track_indx"),
            # ])
            # output_schema = mlflow.types.Schema([
            #     mlflow.types.ColSpec("float",'p95'),
            #     mlflow.types.ColSpec("float",'p75'),
            #     mlflow.types.ColSpec("float",'p50'),
            #     mlflow.types.ColSpec("float",'p25'),
            #     mlflow.types.ColSpec("float",'p5')
            # ])
            # signature = mlflow.models.ModelSignature(inputs=input_schema, outputs=output_schema)

            mlflow.log_param("artist_name", self.artist_name)
            mlflow.log_param("track_name", self.track_name)
            mlflow.log_param("country_code", self.country_code)
            mlflow.log_param("dsp", self.dsp)
            mlflow.log_param("horizon", self.horizon)
            # mlflow.log_param('ad_spend_input', self.ad_spend_input)

            mlflow.log_metric(
                "pred_density",
                float(
                    self.model_instance.model.log_pred_density(self.inference_data_dict)
                ),
            )
            mlflow.log_metric("num_obv", float(len(self.inference_data_dict["week"])))
            try:
                mlflow.log_metric(
                    "pred_density/num_obv",
                    self.model_instance.model.log_pred_density(self.inference_data_dict)
                    / float(len(self.inference_data_dict["week"])),
                )
            except:
                print("could not log pred_density")
                pass

            mlflow.set_tag("request_id", self.request_id)
            mlflow.set_tag("artist_name", self.artist_name)
            mlflow.set_tag("track_name", self.track_name)
            mlflow.set_tag("country_code", self.country_code)
            mlflow.set_tag("dsp", self.dsp)
            mlflow.set_tag("horizon", self.horizon)
            mlflow.set_tag("ad_spend_input", self.ad_spend_input)
            try:
                mlflow.pyfunc.log_model(
                    artifact_path="model",
                    artifacts={
                        "model_path": "s3://wmg-databricks/mlflow/hf/" + self.run_id
                    },
                    python_model=self.model_instance,
                    # signature=signature
                )
            except:
                pass
            return self._output()

    def _output(self):

        streams = self.predictions_dict["predicted_streams"]
        plot = {
            "mean": list(np.mean(streams, axis=0)),
            "95": list(np.maximum(np.percentile(streams, q=95, axis=0), 0)),
            "75": list(np.maximum(np.percentile(streams, q=75, axis=0), 0)),
            "50": list(np.maximum(np.percentile(streams, q=50, axis=0), 0)),
            "25": list(np.maximum(np.percentile(streams, q=25, axis=0), 0)),
            "5": list(np.maximum(np.percentile(streams, q=5, axis=0), 0)),
        }

        streams_ = [v.tolist() for v in streams]

        plot_ = json.dumps(plot)
        streams_ = json.dumps(streams_)
        inference_data_dict_ = json.dumps(self.inference_data_dict)
        # historic_data = json.dumps(historic_data)
        results = {}
        results["artifacts"] = f"s3://wmg-databricks/mlflow/hf/{self.run_id}/artifacts"
        results["plot"] = plot
        results["streams"] = streams_
        results["inference_data_dict"] = inference_data_dict_
        results["historic_data"] = self.historic_data
        results["similar_tracks"] = self.related_artists_list

        results_ = json.dumps(results)

        return results_

